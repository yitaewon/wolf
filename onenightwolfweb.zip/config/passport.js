var passport      = require("passport");
var LocalStrategy = require("passport-local");
var KakaoStrategy = require('passport-kakao').Strategy;
var secret_config = require('./secret');
var User          = require("../models/User");

// serialize & deserialize User
passport.serializeUser(function(user, done) {
  done(null, user.id);
});
passport.deserializeUser(function(id, done) {
  User.findOne({_id:id}, function(err, user) {
    done(err, user);
  });
});

// Kakao strategy
passport.use(new KakaoStrategy({
    clientID: secret_config.federation.kakao.client_id,
    callbackURL: secret_config.federation.kakao.callback_url
  }, (req, accessToken, refreshToken, profile, done) => {
    const profileJson = profile._json;
    User.findOne({ auth_id: profile.id }, (err, user) => {
      if (user) {
        return done(err, user);
      } // 회원 정보가 있으면 로그인
      let randName = Math.random().toString(36).substring(2);
      const newUser = new User({ // 없으면 회원 생성
        username: randName,
        auth_type: profile.provider,
        auth_id: profile.id,
        auth_name: profile.username,
        auth_displayName: profile.displayName,
        auth_profile_img: profileJson.properties.profile_image,
        auth_thumbnail_img: profileJson.properties.thumbnail_image,
        status: 'newbie',
        icon: 'newbie',
        level: 0,
        exp: 0,
        rating: 0,
        color: '#FFFFFF',
      });
      newUser.save((err, user) => {
        if(err) return console.error(err);
        return done(null, user); // 새로운 회원 생성 후 로그인
      });
    });
  }
));

module.exports = passport;
