var login = {};

login.parseError = function(errors){
  var parsed = {};
  if(errors.name == 'ValidationError'){
    for(var name in errors.errors){
      var validationError = errors.errors[name];
      parsed[name] = { message:validationError.message };
    }
  } else if(errors.code == "11000" && errors.errmsg.indexOf("username") > 0) {
    parsed.username = { message:"This username already exists!" };
  } else if(errors.code == "11000" && errors.errmsg.indexOf("cardId") > 0) {
    parsed.cardId = { message:"This card_id already exists!" };
  } else {
    parsed.unhandled = JSON.stringify(errors);
  }
  return parsed;
};

login.isLoggedin = function(req, res, next){
  next()
  /*
  if(req.isAuthenticated()){
    next();
  } else {
    req.flash("errors", {login:"Please login first"});
    res.redirect("/login");
  }
  */
};

login.noPermission = function(req, res){
  req.flash("errors", {login:"You don't have permission"});
  req.logout();
  res.redirect("/login");
};

module.exports = login;
