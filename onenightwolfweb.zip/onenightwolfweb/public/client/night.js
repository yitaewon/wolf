

function showGameStep() {
  var img, role, desc, div;
  img = document.createElement("img");
  img.className = "align-self-center mr-3";
  img.src="/images/wolf_1_seer.jpg";
  img.style.width = "100px";
  document.getElementById("gameSteps").appendChild(img);

  div = document.createElement("div");
  div.className = "media-body align-self-center";
  role = document.createElement("h4");
  role.innerHTML = "씨어";
  desc = document.createElement("p");
  desc.innerHTML = "씨어는 가운데 놓여진 카드 3장 중 2장을 보거나 다른 사람의 카드 한 장을 확인합니다.";

  div.appendChild(role);
  div.appendChild(desc);
  document.getElementById("gameSteps").appendChild(div);
}
showGameStep();

function showMyRole() {
  var img, role, desc, div;
  img = document.createElement("img");
  img.className = "align-self-center mr-3";
  img.src="/images/wolf_1_werewolf.jpg";
  img.style.width = "100px";
  document.getElementById("gameMyRole").appendChild(img);

  div = document.createElement("div");
  div.className = "media-body align-self-center";
  role = document.createElement("h4");
  role.innerHTML = "당신의 직업은 ".concat("웨어울프").concat("입니다.");
  desc = document.createElement("p");
  desc.innerHTML = "자신의 차례때 눈을 떠 다른 늑대인간을 확인합니다. 만약 자신 혼자 늑대인간 일 경우는 가운데 카드 중 한장을 확인 할 수 있습니다.";

  div.appendChild(role);
  div.appendChild(desc);
  document.getElementById("gameMyRole").appendChild(div);
}
showMyRole();
