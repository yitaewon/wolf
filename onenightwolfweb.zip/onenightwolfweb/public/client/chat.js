// join room
function joinRoom(roomid, userid, username) {
  socket.emit('join room',roomid,userid,username);
}
// leave room
function leaveRoom(roomid, userid,username) {
  socket.emit('leave room',roomid,userid,username);
}

// chat message
socket.on('chat message', function(data){
	var span = $('<span class="nickname">').text(data.username).append(' : ');
	var li = $('<li>').append(span).append(data.message).css('color', '#FFFFFF');
	$('#chatMsg').append(li);
	$("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);
});




$('form').submit(function(){
	if($('#chatInput').val()[0]==='/'){
		if($('#chatInput').val()[1]==='s'){
			socket.emit('game start');
			$('#chatInput').val('');
		}
		else if($('#chatInput').val()[1]==='e'){
			socket.emit('game end');
			$('#chatInput').val('');
		}
		else if($('#chatInput').val()[1]==='r'){
			socket.emit('game result');
			$('#chatInput').val('');
		}
		else if($('#chatInput').val()[1]==='c'){
			socket.emit('game continue');
			$('#chatInput').val('');
		}
		else if($('#chatInput').val()[1]==='v'){
			var vote = $('#chatInput').val().substring(3);
			socket.emit('game vote', {
				vote: vote
			});
			$('#chatInput').val('');
		}
	}
	else if($('#chatInput').val()===''){
		return false;
	}
	else{
  	socket.emit('chat message', $('#chatInput').val());
  	$('#chatInput').val('');
	}
	return false;
}); //client에서 server로 msg 전송
