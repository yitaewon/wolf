// join room
function saveRoles(roomid, roleIds) {
  socket.emit('save roles', roomid, roleIds);
}

// show user list on rooms
socket.on('show users', function(users, master){
  var tr, td, div;
  $('#userRoom').empty();
  for (let user of users) {
    tr = document.createElement("tr");

    td = document.createElement("td");
    div = document.createElement("div");
    td.className = "level";
    div.className = "ellipsis";
    div.innerHTML = user.player.level;
    td.appendChild(div);
    tr.appendChild(td);

    td = document.createElement("td");
    div = document.createElement("div");
    td.className = "rating";
    div.className = "ellipsis";
    div.innerHTML = user.player.rating;
    td.appendChild(div);
    tr.appendChild(td);

    td = document.createElement("td");
    div = document.createElement("div");
    td.className = "player";
    div.className = "ellipsis";
    if (user.player._id === master._id) {
      div.innerHTML = "ⓜ ".concat(user.player.username);
    } else {
      div.innerHTML = user.player.username;
    }
    td.appendChild(div);
    tr.appendChild(td);

    td = document.createElement("td");
    div = document.createElement("div");
    td.className = "ready";
    div.className = "ellipsis";
    if (user.player.isReady === true) {
      div.innerHTML = "준비완료";
    } else {
      div.innerHTML = "준비";
    }
    td.appendChild(div);
    tr.appendChild(td);

    document.getElementById("userRoom").appendChild(tr);
  }
});

// show roles on room
function showRoleRoom(roleSrcs) {
  socket.emit('show roles', roleSrcs);
}

socket.on('show roles', function(roleSrcs){
  var elem;
  for (let role of roleSrcs) {
    elem = document.createElement("img");
    elem.className = "imgRoleRoom";
    elem.src = role.image;
    document.getElementById("roleRoom").appendChild(elem);
  }
  $('#roleRoomNum').text(Object.keys(roleSrcs).length);
});

// start game
function startGame(roomid) {
  socket.emit('start game', roomid);
}

socket.on('start game', function(roomid){
  location.href='/rooms/'.concat(roomid).concat('/night');
});
