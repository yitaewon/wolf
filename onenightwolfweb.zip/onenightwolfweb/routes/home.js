var express = require("express");
var router  = express.Router();
var passport= require("../config/passport");
var login     = require("../common/login");
var Room     = require("../models/Room");

// Home
router.get("/", login.isLoggedin, function(req, res){
  res.redirect("/lobby");
});

// room list
router.get("/lobby", login.isLoggedin, function(req, res){
  var room = req.flash("room")[0] || {};
  var errors = req.flash("errors")[0] || {};
  Room.find({})
  .populate("master")
  .sort("-createdAt")
  .exec(function(err, rooms){
    if(err) return res.json(err);
    res.render("home/lobby", {rooms:rooms, room:room, errors:errors});
  });
});

// room create
router.post("/lobby", login.isLoggedin, function(req, res){
  req.body.master = req.user._id;
  req.body.members = [{player:req.user._id,isReady:false}];
  Room.create(req.body, function(err, room){
    if(err){
      req.flash("room", req.body);
      req.flash("errors", login.parseError(err));
      console.log(arguments.callee.name, err);
      return res.redirect("/lobby");
    }
    res.redirect("/rooms/" + room._id);
  });
});

router.get("/about", function(req, res){
  res.render("home/about");
});

// 로그인 페이지
router.get("/login", function(req, res){
  res.render("home/login");
});
// kakao 로그인
router.get('/auth/login/kakao',
  passport.authenticate('kakao')
);
// kakao 로그인 연동 콜백
router.get('/auth/login/kakao/callback',
  passport.authenticate('kakao', {
    successRedirect: '/',
    failureRedirect: '/login'
  })
);
// Logout
router.get("/logout", function(req, res) {
  req.logout();
  res.redirect("/login");
});

module.exports = router;
