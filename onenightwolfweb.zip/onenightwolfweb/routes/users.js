var express  = require("express");
var router   = express.Router();
var User     = require("../models/User");
var login     = require("../common/login");

// Index
router.get("/", login.isLoggedin, function(req, res){
  User.find({})
  .sort({username:1})
  .exec(function(err, users){
    if(err) return res.json(err);
    res.render("users/index", {users:users});
  });
});

// show
router.get("/:id", login.isLoggedin, function(req, res){
  User.findOne({_id:req.params.id}, function(err, user){
    if(err) return res.json(err);
    res.render("users/show", {user:user});
  });
});

// edit
router.get("/:id/edit", login.isLoggedin, checkPermission, function(req, res){
  var user = req.flash("user")[0];
  var errors = req.flash("errors")[0] || {};
  if(!user){
    User.findOne({_id:req.params.id}, function(err, user){
      if(err) return res.json(err);
      res.render("users/edit", { userid:req.params.id, user:user, errors:errors });
    });
  } else {
    res.render("users/edit", { userid:req.params.id, user:user, errors:errors });
  }
});

// update
router.put("/:id", login.isLoggedin, checkPermission, function(req, res, next){
  req.body.updatedAt = Date.now();
  User.findOne({_id:req.params.id})
  .exec(function(err, user){
    if(err) return res.json(err);

    // update user object
    for(var p in req.body){
      user[p] = req.body[p];
    }

    // save updated user
    user.save(function(err, user){
      if(err){
        req.flash("user", req.body);
        req.flash("errors", login.parseError(err));
        return res.redirect("/users/"+req.params.id+"/edit");
      }
      res.redirect("/users/"+user._id);
    });
  });
});

module.exports = router;

// private functions
function checkPermission(req, res, next){
  User.findOne({_id:req.params.id}, function(err, user){
    if(err) return res.json(err);
    if(user.id != req.user.id) return login.noPermission(req, res);

    next();
  });
}
