var express  = require("express");
var router   = express.Router();
var Role     = require("../models/Role");
var User     = require("../models/User");
var login     = require("../common/login");

// Index
router.get("/", login.isLoggedin, function(req, res){
  Role.find({})
  .sort({cardId:1})
  .exec(function(err, roles){
    if(err) return res.json(err);
    res.render("roles/index", {roles:roles});
  });
});

// New
router.get("/new", login.isLoggedin, function(req, res){
  var role = req.flash("role")[0] || {};
  var errors = req.flash("errors")[0] || {};
  res.render("roles/new", { role:role, errors:errors });
});


// create
router.post("/", login.isLoggedin, function(req, res){
  Role.create(req.body, function(err, role){
    if(err){
      req.flash("role", req.body);
      req.flash("errors", login.parseError(err));
      return res.redirect("/roles/new");
    }
    res.redirect("/roles");
  });
});

// show
router.get("/:id", login.isLoggedin, function(req, res){
  Role.findOne({_id:req.params.id}, function(err, role){
    if(err) return res.json(err);
    res.render("roles/show", {role:role});
  });
});

// edit
router.get("/:id/edit", login.isLoggedin, checkPermissionAdmin, function(req, res){
  var role = req.flash("role")[0];
  var errors = req.flash("errors")[0] || {};
  if(!role){
    Role.findOne({_id:req.params.id}, function(err, role){
      if(err) return res.json(err);
      res.render("roles/edit", { roleid:req.params.id, role:role, errors:errors });
    });
  } else {
    res.render("roles/edit", { roleid:req.params.id, role:role, errors:errors });
  }
});

// update
router.put("/:id", login.isLoggedin, checkPermissionAdmin, function(req, res, next){
  req.body.updatedAt = Date.now();
  Role.findOne({_id:req.params.id})
  .exec(function(err, role){
    if(err) return res.json(err);

    // update role object
    for(var p in req.body){
      role[p] = req.body[p];
    }

    // save updated role
    role.save(function(err, role){
      if(err){
        req.flash("role", req.body);
        req.flash("errors", login.parseError(err));
        return res.redirect("/roles/"+req.params.id+"/edit");
      }
      res.redirect("/roles/"+role._id);
    });
  });
});

module.exports = router;

// private functions
function checkPermissionAdmin(req, res, next){
  User.findOne({_id:req.user.id}, function(err, user){
    if(err) return res.json(err);
    if(user.status != 'admin') return login.noPermission(req, res);

    next();
  });
}
