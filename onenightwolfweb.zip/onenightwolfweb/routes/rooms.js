var express = require("express");
var router  = express.Router();
var login     = require("../common/login");
var Role     = require("../models/Role");
var Room     = require("../models/Room");

// show
router.get("/:id", login.isLoggedin, function(req, res){
  var roles;
  Role.find({})
  .sort({cardId:1})
  .exec(function(err, cardRoles){
    if(err) return res.json(err);
    roles = cardRoles;
  });

  Room.findOne({_id:req.params.id})
  .populate("master")
  .populate("members.player")
  .populate("roles.card")
  .exec(function(err, room){
    if(err) return res.json(err);
    //console.log(arguments.callee.name, room);
    //console.log(arguments.callee.name, req.user);
    //console.log(arguments.callee.name, roles);
    res.render("rooms/show", {room:room, user:req.user, roles:roles});
  });
});

// update
router.post("/:id", login.isLoggedin, function(req, res){
  res.redirect("/rooms/"+req.params.id);
});

// gmae play turn night
router.get("/:id/night", login.isLoggedin, function(req, res){
  Room.findOne({_id:req.params.id})
  .populate("master")
  .populate("members.player")
  .populate("roles.card")
  .exec(function(err, room){
    if(err) return res.json(err);
    console.log(arguments.callee.name, room);
    //console.log(arguments.callee.name, req.user);
    //console.log(arguments.callee.name, roles);
    res.render("rooms/night", {room:room, user:req.user});
  });
});

module.exports = router;
