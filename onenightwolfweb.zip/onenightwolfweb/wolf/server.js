var Room     = require("../models/Room");
var User     = require("../models/User");
var Role     = require("../models/Role");
var util     = require("../common/util");
var rooms = {};

// define constructor function that gets `io` send to it
module.exports = function(io) {
  const bluffio = io.of('/wolf');
  bluffio.on('connection', function(socket){

    socket.on('join room',function(roomid, userid, username){
      socket.roomid = roomid;
      socket.userid = userid;
      socket.username = username;
      socket.join(roomid);

      console.log('[Join Room]', socket.roomid, socket.username);
      // push user to room
      Room.findOne({_id:roomid})
      .exec(function(err, room){
        if(err) {
          console.log(err);
          return;
        }
        // check user is in the room
        if (chkRoomUser(room, userid) === true) {
          for (let i=0; i<room.members.length; i++) {
            // refresh socket id
            if (room.members[i].player.equals(userid)) {
              room.members[i].socketid = socket.id;
              break;
            }
          }
        } else {
          room.members.push({player:userid,isReady:false,socketid:socket.id});
        }
        room.save(function(err, room){
          if(err){
            console.log(err);
            return;
          }
          // show user list
          Room.findOne({_id:roomid})
          .populate("master")
          .populate("members.player")
          .exec(function(err, room){
            if(err) {
              console.log(err);
              return;
            }
            socket.emit('show users', room.members, room.master);
          });
        });
      });
    }); // join room

    socket.on('leave room',function(roomid, userid, username){
      console.log('[Leave Room]', socket.roomid, socket.username);
      roomDeleteUser(roomid, userid);
      socket.roomid = undefined;
      socket.userid = undefined;
      socket.username = undefined;
      socket.leave(roomid);
    }); // leave room

    socket.on('chat message', function(msg){
      //socket.broadcast.to(room_id).emit('msgAlert',data); //자신 제외 룸안의 유저
      //socket.in(room_id).emit('msgAlert',data); //broadcast 동일하게 가능 자신 제외 룸안의 유저
      //io.of('namespace').in(room_id).emit('msgAlert', data) //of 지정된 name space의 유저의 룸
      bluffio.to(socket.roomid).emit('chat message', {
        username: socket.username,
        message: msg
      });
    }); // chat message

    socket.on('save roles', function(roomid, roles) {
      roomPushRoles(roomid, roles);
    }); // save roles

    socket.on('show roles', function(roleSrcs) {
      socket.emit('show roles', roleSrcs);
    }); // show roles

    socket.on('start game', function(roomid) {
      Room.findOne({_id:roomid})
      .populate("members.player")
      .populate("roles.card")
      .exec(function(err, room){
        if(err) {
          console.log(err);
          return;
        }
        // sort game roles
        room.gameRoles = [];
        for (let role of room.roles) {
          room.gameRoles.push({name:role.card.name, turn:role.card.turn});
        }
        room.gameRoles.sort(function(a,b) {
          return a.turn - b.turn;
        });
        // add role to players
        var randomRoles = util.shuffleArray(room.gameRoles);
        room.gamePlayers = [];
        for (let i=0; i<room.members.length; i++) {
          room.gamePlayers.push({name:room.members[i].player.name, originalRole:randomRoles[i], cardRole:randomRoles[i]});
        }
        // change status
        room.status = "start";
        room.save(function(err, room){
          if(err){
            console.log(err);
            return;
          }
          socket.emit('start game', roomid);
        });
      });
    }); // start game
  });
}

function startInitGame(roomid) {
  Room.findOne({_id:roomid})
  .populate("members.player")
  .populate("roles.card")
  .exec(function(err, room){
    if(err) {
      console.log(err);
      return;
    }
    // sort game roles
    room.gameRoles = [];
    for (let role of room.roles) {
      room.gameRoles.push({name:role.card.name, turn:role.card.turn});
    }
    room.gameRoles.sort(function(a,b) {
      return a.turn - b.turn;
    });
    // add role to players
    var randomRoles = util.shuffleArray(room.gameRoles);
    room.gamePlayers = [];
    for (let i=0; i<room.members.length; i++) {
      room.gamePlayers.push({name:room.members[i].player.name, originalRole:randomRoles[i], cardRole:randomRoles[i]});
    }
    // change status
    room.status = "start";
    room.save(function(err, room){
      if(err){
        console.log(err);
        return;
      }
    });
  });
}

function roomPushRoles(roomid, roles) {
  Room.findOne({_id:roomid})
  .exec(function(err, room){
    if(err) {
      console.log(err);
      return;
    }
    room.roles = [];
    for (let role of roles) {
      room.roles.push({card:role});
    }
    room.save(function(err, room){
      if(err){
        console.log(err);
        return;
      }
    });
  });
}

function roomDeleteUser(roomid, userid) {
  Room.findOne({_id:roomid})
  .exec(function(err, room){
    if(err) {
      console.log(err);
      return;
    }
    // if room master
    if (room.master._id.equals(userid)) {
      Room.deleteOne({_id:roomid}, function(err){
        console.log(err);
        return;
      });
    } else {
      for (let idx=0; idx<room.members.length; idx++) {
        if (room.members[idx].player._id.equals(userid)) {
          room.members.splice(idx, 1);
          room.save(function(err, room){
            if(err){
              console.log(err);
              return;
            }
          });
          break;
        }
      }
    }
  });
}

function roomPushUser(roomid, userid) {
  Room.findOne({_id:roomid})
  .exec(function(err, room){
    if(err) {
      console.log(err);
      return;
    }
    if (chkRoomUser(room, userid) === true) {
      return;
    }
    room.members.push({player:userid,isReady:false});
    room.save(function(err, room){
      if(err){
        console.log(err);
        return;
      }
    });
  });
}

function chkRoomUser(room, userid) {
  for (let m of room.members) {
    if (m.player._id.equals(userid)) {
      return true;
    }
  }
  return false;
}
