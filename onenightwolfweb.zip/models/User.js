var mongoose = require("mongoose");
var util     = require("../common/util");

// schema
var userSchema = mongoose.Schema({
  username:{
    type:String,
    required:[true,"Username is required!"],
    match:[/^.{2,12}$/,"Should be 2-12 characters!"],
    trim:true,
    unique:true
  },
  createdAt:{
    type:Date,
    default:Date.now
  },
  updatedAt:{
    type:Date
  },
  status:{
    type:String,
    trim:true
  },
  icon:{
    type:String,
    trim:true
  },
  level:{
    type:Number,
  },
  exp:{
    type:Number,
  },
  rating:{
    type:Number,
  },
  color:{
    type:String,
    trim:true
  },
  auth_type:{
    type:String,
    trim:true
  },
  auth_id:{
    type:String,
    trim:true
  },
  auth_name:{
    type:String,
    trim:true
  },
  auth_displayName:{
    type:String,
    trim:true
  },
  auth_profile_img:{
    type:String,
    trim:true
  },
  auth_thumbnail_img:{
    type:String,
    trim:true
  },
  email:{
    type:String,
    match:[/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,"Should be a vaild email address!"],
    trim:true
  }
},{
  toObject:{virtuals:true}
});

// virtuals
userSchema.virtual("createdDate")
.get(function(){
  return util.getDate(this.createdAt);
});

userSchema.virtual("createdTime")
.get(function(){
  return util.getTime(this.createdAt);
});

userSchema.virtual("updatedDate")
.get(function(){
  return util.getDate(this.updatedAt);
});

userSchema.virtual("updatedTime")
.get(function(){
  return util.getTime(this.updatedAt);
});

// model & export
var User = mongoose.model("user",userSchema);
module.exports = User;
