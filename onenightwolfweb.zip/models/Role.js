var mongoose = require("mongoose");
var util     = require("../common/util");

// schema
var roleSchema = mongoose.Schema({
  name:{
    type:String,
    trim:true
  },
  description: {
    type:String,
    trim:true
  },
  cardId: {
    type:Number,
    unique:true
  },
  series: {
    type:String,
    trim:true
  },
  team: {
    type:String,
    trim:true
  },
  turn: {
    type:Number
  },
  image: {
    type:String,
    trim:true
  },
  createdAt:{
    type:Date,
    default:Date.now
  },
  updatedAt:{
    type:Date
  },
},{
  toObject:{virtuals:true}
});

// virtuals
roleSchema.virtual("createdDate")
.get(function(){
  return util.getDate(this.createdAt);
});

roleSchema.virtual("createdTime")
.get(function(){
  return util.getTime(this.createdAt);
});

roleSchema.virtual("updatedDate")
.get(function(){
  return util.getDate(this.updatedAt);
});

roleSchema.virtual("updatedTime")
.get(function(){
  return util.getTime(this.updatedAt);
});

// model & export
var Role = mongoose.model("role",roleSchema);
module.exports = Role;
