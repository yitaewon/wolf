var mongoose = require("mongoose");
var util     = require("../common/util");

// schema
var roomSchema = mongoose.Schema({
  title:{
    type:String,
    required:[true,"Title is required!"],
    match:[/^.{2,30}$/,"Should be 2-30 characters!"],
    trim:true,
  },
  createdAt:{
    type:Date,
    default:Date.now
  },
  updatedAt:{
    type:Date
  },
  isPrivate: {
    type:Boolean
  },
  password: {
    type:String,
    trim:true
  },
  status: {
    type:String,
    trim:true,
    default: 'ready'
  },
  master:{
    type:mongoose.Schema.Types.ObjectId,
    ref:"user",
    required:true
  },
  members: [{
    player:{
      type:mongoose.Schema.Types.ObjectId,
      ref:"user",
      required:true
    },
    socketid:{
      type:String
    },
    isReady:{
      type:Boolean
    },
  }],
  gameRoles: [{
    name:{
      type:String,
      trim:true
    },
    turn:{
      type:Number
    }
  }],
  gamePlayers: [{
    name:{
      type:String,
      trim:true
    },
    originalRole:{
      type:String,
      trim:true
    },
    cardRole:{
      type:String,
      trim:true
    },
    lastRole:{
      type:String,
      trim:true
    },
  }],
  numbers: {
    type:Number
  },
  roles: [{
    card:{
      type:mongoose.Schema.Types.ObjectId,
      ref:"role",
      required:true
    }
  }],
},{
  toObject:{virtuals:true}
});

// virtuals
roomSchema.virtual("createdDate")
.get(function(){
  return util.getDateRoom(this.createdAt);
});

roomSchema.virtual("createdTime")
.get(function(){
  return util.getTime(this.createdAt);
});

roomSchema.virtual("updatedDate")
.get(function(){
  return util.getDateRoom(this.updatedAt);
});

roomSchema.virtual("updatedTime")
.get(function(){
  return util.getTime(this.updatedAt);
});

// model & export
var Room = mongoose.model("room", roomSchema);
module.exports = Room;
