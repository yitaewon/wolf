var chatPage = $('.chat.page');
chatPage.show();
var GameStatus = 'end';

var COLORS = [
	'#e21400', '#91580f', '#f8a700', '#f78b00',
	'#58dc00', '#287b00', '#a8f07a', '#4ae8c4',
	'#3b88eb', '#3824aa', '#a700ff', '#d300e7'
];
function getColor(username){
	var hash = 7;
	for (var i = 0; i < username.length; i++) {
		 hash = username.charCodeAt(i) + (hash << 5) - hash;
	}
	var index = Math.abs(hash % COLORS.length);
	return COLORS[index];
}// 이름에 색칠 정해주기

function userListUpdate(userlist){
	$('#userList').text('');
	var str='';
	for(var i=0; i<userlist.length; i++){
		if(i==(userlist.length-1))
			{str+= userlist[i];}
		else
			{str += userlist[i]+', ';}
	}
	$('#userList').text(str);
}

$('form').submit(function(){
	if($('#m').val()[0]=='/'){
			if( ($('#m').val()[1]=='w') && (GameStatus=='end') ){
				var newmsg = $('#m').val().substring(3);
				var index = newmsg.indexOf(' ');
				var to = newmsg.substring(0,index);
				var msg = newmsg.substring(index+1,newmsg.length);
				if(msg != ''){
					socket.emit('whisper',{
						To:to,
						Msg:msg
					});
				}
				$('#m').val('/w ' + to + ' ');
			}
			else if($('#m').val()[1]=='s'){
				var gameTitle = $('#m').val().substring(3);
				socket.emit('gameStart',{
					GameTitle:gameTitle
				});
				$('#m').val('');
			}
			else if($('#m').val()[1]=='e'){
				socket.emit('gameEnd');
				$('#m').val('');
			}
			else if($('#m').val()[1]=='p'){
				socket.emit('gamePoint');
				$('#m').val('');
			}
	}
	else if($('#m').val()==''){
		return false;
	}
	else{
	socket.emit('chat message', $('#m').val());
	$('#m').val('');
	}
	return false;
});// client에서 server로 msg 전송

socket.on('new nickname', function(data){
	$('#messages').append($('<li class="noti">').text(data.pastname + '님이 ' +data.newname+'으로 닉네임을 변경하였습니다.' ));
	$("#messages").animate({scrollTop: $('#messages').prop("scrollHeight")}, 0);
	userListUpdate(data.userlist);
});

socket.on('chat message', function(data){
	var span = $('<span class="nickname">').text(data.username).css('color', getColor(data.username)).append(' : ');
	var li = $('<li>').append(span).append(data.message);
	$('#messages').append(li);
	$("#messages").animate({scrollTop: $('#messages').prop("scrollHeight")}, 0);
}); //chat 내용을 채팅창에 출력

socket.on('game message', function(data){
	var gameManager = "Game";
	var span = $('<span class="nickname">').text(gameManager).css('color', 'red').append(' : ');
	var li = $('<li>').append(span).append(data.message);
	$('#messages').append(li);
	$("#messages").animate({scrollTop: $('#messages').prop("scrollHeight")}, 0);
}); //game 내용을 채팅창에 출력

socket.on('ban', function(data){
	var span = $('<span class="nickname">').text(data.username).css('color', getColor(data.username)).append(' : ');
	var li = $('<li>').append(span).append(data.message);
	$('#messages').append(li);
	window.location.href = '/posts';
});

socket.on('user joined', function(data){
	$('#messages').append($('<li class="noti">').text(data.username + '님이 입장하셨습니다'));
	$("#messages").animate({scrollTop: $('#messages').prop("scrollHeight")}, 0);
	userListUpdate(data.userlist);
});

socket.on('new people',function(data){
	//$('#messages').append($('<li class="noti">').text(data.username + '님이 입장하셨습니다'));
	userListUpdate(data.userlist);
});

socket.on('user logout',function(data){
	$('#messages').append($('<li class="noti">').text(data.username + '님이 퇴장하셨습니다'));
	$("#messages").animate({scrollTop: $('#messages').prop("scrollHeight")}, 0);
	userListUpdate(data.userlist);
});

///////////////////////////////////////////////////// Game Socket
socket.on('game start', function(){
	GameStatus = 'start';
});

socket.on('game end', function(){
	GameStatus = 'end';
});

socket.on('game card exchange', function(){
	GameStatus = 'exchange';
});

socket.on('game play', function(){
	GameStatus = 'play';
});

socket.on('update player cards', function(data){
	var playerCards = data.playerCards;
	sortCard(playerCards);
	updateCard(playerCards);
	drawCard();
});

socket.on('update player cards selected', function(data){
	var playerCards = data.playerCards;
	var selectedCards = data.selectedCards;
	sortCard(playerCards);
	updateCard(playerCards);
	drawSelctedCard(selectedCards);
});

socket.on('update table cards', function(data){
	updateTable(data);
	drawTable();
});

socket.on('update player list', function(data){
	drawPlayerList(data.playersInfo);
});

socket.on('update table status', function(data){
	updateTableStatus(data);
	GameStatus = data.step;
});
