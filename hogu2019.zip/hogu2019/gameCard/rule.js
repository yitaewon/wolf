var gameRule = {};

var CombSingle = 'single';
var CombPair = 'pair';
var CombTriple = 'triple';
var CombFourCard = 'four card';
var CombStraight = 'straight';

function LabelCombi(isValid, len, max, combi, numbers, suits) {
  this.isValid = isValid,
	this.len = len,
  this.max = max,
  this.combi = combi,
  this.numbers = numbers,
  this.suits = suits
}

function falseLabelCombi() {
  return new LabelCombi(false, false, false, false, false, false);
}

gameRule.isCombine = function(cards) {
  var value = {};
  value = isSingle(cards);
  if (value.isValid == true) {
    return value;
  }
  value = isPair(cards);
  if (value.isValid == true) {
    return value;
  }
  value = isStraight(cards);
  if (value.isValid == true) {
    return value;
  }
  return falseLabelCombi();
};

function isSingle(cards) {
  if (cards.length != 1) {
    return falseLabelCombi();
  }
  var numbers = [];
  var suits = [];
  numbers.push(cards[0].number);
  suits.push(cards[0].suit);
  return new LabelCombi(true, cards.length, cards[0].number, CombSingle, numbers, suits);
}

function isPair(cards) {
  if ((cards.length < 2) || (cards.length > 4)) {
    return falseLabelCombi();
  }
  var numbers = [];
  var suits = [];
  var num = 'joker';
  for (var i = 0; i < cards.length; i++) {
    numbers.push(cards[i].number);
    suits.push(cards[i].suit);
    if (cards[i].number == 'joker') {
      continue;
    }
    else if (num == 'joker') {
      num = cards[i].number;
    }
    else if (num != cards[i].number) {
      return falseLabelCombi();
    }
  }

  if (cards.length == 2) {
    return new LabelCombi(true, 2, num, CombPair, numbers, suits);
  }
  else if (cards.length == 3) {
    return new LabelCombi(true, 3, num, CombTriple, numbers, suits);
  }
  else if (cards.length == 4) {
    return new LabelCombi(true, 4, num, CombFourCard, numbers, suits);
  }
}

function isStraight(cards) {
  if (cards.length < 3) {
    return falseLabelCombi();
  }
  var intOfNumbers = [];
  var jokerNum = 0;
  var numbers = [];
  var suits = [];
  var suit = '';
  for (var i = 0; i < cards.length; i++) {
    numbers.push(cards[i].number);
    suits.push(cards[i].suit);
    if (cards[i].number == 'joker') {
      jokerNum++;
      continue;
    }
    var intNum = cardNumToInt(cards[i].number);
    intOfNumbers.push(intNum);
    if (suit == '') {
      suit = cards[i].suit;
    }
    else if (suit != cards[i].suit) {
      return falseLabelCombi();
    }
  }

  var maxNum = Math.max(...intOfNumbers);
  var minNum = Math.min(...intOfNumbers);
  var straightLen = maxNum - minNum + 1;
  if (straightLen > cards.length) {
    return falseLabelCombi();
  }
  else if (straightLen == cards.length) {
    return new LabelCombi(true, cards.length, cardIntToNum(maxNum), CombStraight, numbers, suits);
  }
  else if (straightLen == (cards.length-1)) {
    return new LabelCombi(true, cards.length, cardIntToNum(maxNum+1), CombStraight, numbers, suits);
  }
  else if (straightLen == (cards.length-2)) {
    return new LabelCombi(true, cards.length, cardIntToNum(maxNum+2), CombStraight, numbers, suits);
  }
}

function cardNumToInt(str) {
  if (str == 'J') {
    return 11;
  }
  else if (str == 'Q') {
    return 12;
  }
  else if (str == 'K') {
    return 13;
  }
  else if (str == 'A') {
    return 14;
  }
  else if (str == '2') {
    return 15;
  }
  return parseInt(str);
}

function cardIntToNum(val) {
  if (val == 11) {
    return 'J';
  }
  else if (val == 12) {
    return 'Q';
  }
  else if (val == 13) {
    return 'K';
  }
  else if (val == 14) {
    return 'A';
  }
  else if (val >= 15) {
    return '2';
  }
  return val.toString();
}


module.exports = gameRule;
