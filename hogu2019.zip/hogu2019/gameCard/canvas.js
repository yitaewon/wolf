var curCards = [];
var curLabelCards = [];
var curLabelSubmit = undefined;
var curLabelPass = undefined;
var curplayersInfo = [];
var preTableCards = [];
var curTableCards = [];
var isUserTurn = false;
var curTableStatus = {
	isTempEight: false,
	isTempReverse: false,
	isReverse: false,
	chainSuits: [],
	chainNum: false
};

var canvasCards = document.getElementById("playerCards");
var ctxCards = canvasCards.getContext("2d");

var canvasTablePre = document.getElementById("playerTablePre");
var ctxTablePre = canvasTablePre.getContext("2d");
var canvasTableCur = document.getElementById("playerTableCur");
var ctxTableCur = canvasTableCur.getContext("2d");
var canvasTableText = document.getElementById("playerTableText");

var canvasSubmit = document.getElementById("turnSubmit");
var canvasPass = document.getElementById('turnPass');

GameDisplayInit();

function GameDisplayInit() {
	drawCard();
	drawButton();
	createTablePlayerList();

	window.addEventListener('resize', handleResize, false);
	//canvasCards.addEventListener("mousemove", handleMouseMove, false);
	canvasCards.addEventListener("mousedown", handleMouseDown, false);
	//canvasCards.addEventListener("mouseup", handleMouseUp, false);
	canvasSubmit.addEventListener("mousedown", handleMouseDownSubmit, false);
	canvasPass.addEventListener("mousedown", handleMouseDownPass, false);
}

function LabelCards(x, y, w, h, suit, number, rank, selected, callback) {
	//x and y are integers betweem 0 and 1. Use as percentages.
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	this.suit = suit;
	this.number = number;
	this.rank = rank;
	this.selected = false;
	this.callback = callback;
}

function updateLabelCards(canvas, cards) {
	newLabelCards = [];
	if (!cards)	return [];
	var len = cards.length;
	for (var i = 0; i < len; i++) {
		var w = Math.min(canvas.width/len, canvas.height/4*3);
		var h = canvas.height;
		var x = i*w;
		var y = 0;
		var selected = false;
		var callbackFunc = undefined;
		newLabelCards.push(new LabelCards(x, y, w, h, cards[i].suit, cards[i].number, cards[i].rank, selected, callbackFunc));
	}
	return newLabelCards;
}

function LabelButton(x, y, w, h, callback) {
	//x and y are integers betweem 0 and 1. Use as percentages.
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	this.callback = callback;
}

function getSelectedCards() {
	selectedCards = []
	for (var i = 0; i < curLabelCards.length; i ++) {
		var cards = curLabelCards[i];
		if (cards.selected == false)	continue;

		selectedCards.push({
			suit: cards.suit,
			number: cards.number,
			rank: cards.rank
		});
	}
	return selectedCards;
}

function callbackSubmit() {
	if (isUserTurn == false) {
		return;
	}

	var selectedCards = getSelectedCards();
	if (selectedCards.length > 0) {
		if (GameStatus == 'exchange') {
			socket.emit('submit card', {
				username: username,
				selectedCards: selectedCards
			});
		} else {
			var combineData = gameRule.isCombine(selectedCards);
			if (combineData.isValid == true) {
				socket.emit('submit card', {
					username: username,
					selectedCards: selectedCards
				});
			}
		}
	}
}

function callbackPass() {
	if (isUserTurn == false) {
		return;
	}
	socket.emit('pass card', {
		username: username
	});
}

function changebg_myturn() {
	$("#displayMyturn").css("background-color","#3BB26F");
}

function changebg_noturn() {
	$("#displayMyturn").css("background-color","black");
}

function updateLabelButtons() {
	curLabelSubmit = new LabelButton(0,0,canvasSubmit.width,canvasSubmit.height, callbackSubmit);
	curLabelPass = new LabelButton(0,0,canvasPass.width,canvasPass.height, callbackPass);
}

function drawButton() {
	canvasSubmit.width = $("#turnSubmit").width();
	canvasSubmit.height = $("#turnSubmit").height();
	canvasPass.width = $("#turnPass").width();
	canvasPass.height = $("#turnPass").height();

	updateLabelButtons();

	drawCanvasText(canvasSubmit,'제출');
	drawCanvasText(canvasPass,'패스');
}

function updateTableStatus(status) {
	curTableStatus.isTempEight = status.data.isTempEight;
	curTableStatus.isTempReverse = status.data.isTempReverse;
	curTableStatus.isReverse = status.data.isReverse;
	curTableStatus.chainSuits = status.data.chainSuits;
	curTableStatus.chainNum = status.data.chainNum;
	drawTableMsg();
}

function drawTableMsg() {
	canvasTableText.width = $("#playerTableText").width();
	canvasTableText.height = $("#playerTableText").height();

	var status = [];
	if (curTableStatus.isTempEight == true) {
		status.push('8스톱');
	}
	if (curTableStatus.isReverse == true) {
		status.push('대혁명!')
	}
	if (curTableStatus.isTempReverse == true) {
		status.push('J 혁명');
	}
	if (curTableStatus.chainSuits.length > 0) {
		status.push('문양묶임');
	}
	if (curTableStatus.chainNum != false) {
		status.push('숫자묶임');
	}
	var tableStatusTxt = status.join(" ");

	drawTableText(canvasTableText, tableStatusTxt);
}

function drawTableText(canvas, text) {
	var context = canvas.getContext("2d");
	context.save();

	var x = canvas.width / 2;
 	var y = canvas.height / 2;
	context.font = "28px Arial";
 	context.fillStyle = '#bfff00';
	context.textAlign = 'center';
	context.textBaseline = 'middle';
	context.fillText(text, x, y);

	context.restore();
}

function drawCanvasText(canvas, text) {
	var context = canvas.getContext("2d");
	context.save();
	context.fillStyle = "black";
	context.font = "20px Arial";
	context.textBaseline = "middle";
	context.textAlign = "center";
	context.fillText(text, canvas.width/2, canvas.height/2);
	context.restore();
}

function drawTable() {
	canvasTablePre.width = $("#playerTablePre").width();
	canvasTablePre.height = $("#playerTablePre").height();
	canvasTableCur.width = $("#playerTableCur").width();
	canvasTableCur.height = $("#playerTableCur").height();

	drawConvasInit(ctxTablePre, "green");

	var tableCardPre = updateLabelCards(canvasTablePre, preTableCards);
	if (tableCardPre.length > 0) {
		for (var i = 0; i < tableCardPre.length; i++) {
			drawSuitCard(ctxTablePre, tableCardPre[i]);
		}
	}

	var tableCardCur = updateLabelCards(canvasTableCur, curTableCards);
	if (tableCardCur.length > 0) {
		for (var i = 0; i < tableCardCur.length; i++) {
			drawSuitCard(ctxTableCur, tableCardCur[i]);
		}
	}
}

function drawConvasInit(context, color) {
	context.save();

	context.fillStyle = color;
	context.fillRect(0, 0, context.width, context.height);

	context.fill();
	context.restore();
}

function drawCard() {
	canvasCards.width = $("#playerCards").width();
	canvasCards.height = $("#playerCards").height();

	drawConvasInit(ctxCards, "green");

	curLabelCards = updateLabelCards(canvasCards, curCards);

	if (curLabelCards.length > 0)
	{
		for (var i = 0; i < curLabelCards.length; i++) {
			drawSuitCard(ctxCards, curLabelCards[i]);
		}
	}
}

function drawSelctedCard(selectedCards) {
	canvasCards.width = $("#playerCards").width();
	canvasCards.height = $("#playerCards").height();

	drawConvasInit(ctxCards, "green");

	curLabelCards = updateLabelCards(canvasCards, curCards);

	var ranks = [];
	for (var i = 0; i < selectedCards.length; i++) {
		ranks.push(selectedCards[i].rank);
	}
	for (i = 0; i < curLabelCards.length; i++) {
		if (ranks.indexOf(curLabelCards[i].rank) != -1) {
			curLabelCards[i].selected = true;
		}
	}

	if (curLabelCards.length > 0)
	{
		for (var i = 0; i < curLabelCards.length; i++) {
			drawSuitCard(ctxCards, curLabelCards[i]);
		}
	}
}

function drawSuitCard(context, cardLabel) {
	var x = cardLabel.x;
	var y = cardLabel.y;
	var w = cardLabel.w;
	var h = cardLabel.h;
	var number = cardLabel.number;
	var suit = cardLabel.suit;
	var rank = cardLabel.rank;
	var selected = cardLabel.selected;
	context.save();
	context.beginPath();
	if (selected) {
		context.fillStyle = '#33ccff';
		context.fillRect(x,y, w, h);
	}
	else {
		context.fillStyle = '#ffffff';
		context.fillRect(x,y, w, h);
	}
	context.strokeStyle="#000000";
	context.strokeRect(x, y, w, h);

	var suit_w = Math.min(Math.max(w * 0.3, 30), w*0.5);
	var suit_h = suit_w*4/3;
	var suit_x = x + suit_w/1.5 + 3;
	var suit_y = y + 3;
	if (number == 'joker'){
		context.font = "20px Arial";
		if (suit == 'black'){
			context.fillStyle = "black";
		}
		else if (suit == 'color'){
			context.fillStyle = "red";
		}
		context.font = "20px Arial";
		context.textBaseline = "middle";
		context.textAlign = "center";
		drawStar(context, suit_x, suit_y + suit_w/2, suit_w/2, 5, 0.5);
		context.save();
		context.translate(suit_x-3, suit_y + suit_w + 35);
		context.rotate(Math.PI/2);
		context.fillText("JOKER",0, 0);
		context.restore();
	}
	else {
		if (suit == 'spade') {
			context.fillStyle = "black";
			drawSpade(context, suit_x, suit_y, suit_w, suit_h);
		}
		else if (suit == 'heart') {
			context.fillStyle = "red";
			drawHeart(context, suit_x, suit_y, suit_w, suit_h);
		}
		else if (suit == 'diamond') {
			context.fillStyle = "red";
			drawDiamond(context, suit_x, suit_y, suit_w, suit_h);
		}
		else if (suit == 'club') {
			context.fillStyle = "black";
			drawClub(context, suit_x, suit_y, suit_w, suit_h);
		}
		context.font = "25px Arial";
		context.textBaseline = "middle";
		context.textAlign = "center";
		context.fillText(number, suit_x, suit_y+suit_h+18);
	}

	context.fill();
	context.restore();
}

function drawSpade(context, x, y, width, height){
	context.save();
	var bottomWidth = width * 0.7;
	var topHeight = height * 0.7;
	var bottomHeight = height * 0.3;
	context.fillStyle = "black";

	context.beginPath();
	context.moveTo(x, y);

	// top left of spade
	context.bezierCurveTo(
		x, y + topHeight / 2, // control point 1
		x - width / 2, y + topHeight / 2, // control point 2
		x - width / 2, y + topHeight // end point
	);

	// bottom left of spade
	context.bezierCurveTo(
		x - width / 2, y + topHeight * 1.3, // control point 1
		x, y + topHeight * 1.3, // control point 2
		x, y + topHeight // end point
	);

	// bottom right of spade
	context.bezierCurveTo(
		x, y + topHeight * 1.3, // control point 1
		x + width / 2, y + topHeight * 1.3, // control point 2
		x + width / 2, y + topHeight // end point
	);

	// top right of spade
	context.bezierCurveTo(
		x + width / 2, y + topHeight / 2, // control point 1
		x, y + topHeight / 2, // control point 2
		x, y // end point
	);
	context.closePath();
	context.fill();

	// bottom of spade
	context.beginPath();
	context.moveTo(x, y + topHeight);
	context.quadraticCurveTo(
		x, y + topHeight + bottomHeight, // control point
		x - bottomWidth / 2, y + topHeight + bottomHeight // end point
	);
	context.lineTo(x + bottomWidth / 2, y + topHeight + bottomHeight);
	context.quadraticCurveTo(
		x, y + topHeight + bottomHeight, // control point
		x, y + topHeight // end point
	);
	context.closePath();
	context.fill();
	context.restore();
}

function drawHeart(context, x, y, width, height){
	context.save();
	context.fillStyle = "red";
	context.beginPath();
	var topCurveHeight = height * 0.3;
	context.moveTo(x, y + topCurveHeight);
	// top left curve
	context.bezierCurveTo(
		x, y,
		x - width / 2, y,
		x - width / 2, y + topCurveHeight
		);

	// bottom left curve
	context.bezierCurveTo(
		x - width / 2, y + (height + topCurveHeight) / 2,
		x, y + (height + topCurveHeight) / 2,
		x, y + height
		);

	// bottom right curve
	context.bezierCurveTo(
		x, y + (height + topCurveHeight) / 2,
		x + width / 2, y + (height + topCurveHeight) / 2,
		x + width / 2, y + topCurveHeight
		);

	// top right curve
	context.bezierCurveTo(
		x + width / 2, y,
		x, y,
		x, y + topCurveHeight
		);

	context.closePath();
	context.fill();
	context.restore();
}

function drawClub(context, x, y, width, height){
	context.save();
	context.fillStyle = "black";
	var circleRadius = width * 0.3;
	var bottomWidth = width * 0.5;
	var bottomHeight = height * 0.35;

	// top circle
	context.beginPath();
	context.arc(
		x, y + circleRadius + (height * 0.05),
		circleRadius, 0, 2 * Math.PI, false
		);
	context.fill();

	// bottom right circle
	context.beginPath();
	context.arc(
		x + circleRadius, y + (height * 0.6),
		circleRadius, 0, 2 * Math.PI, false
		);
	context.fill();

	// bottom left circle
	context.beginPath();
	context.arc(
		x - circleRadius, y + (height * 0.6),
		circleRadius, 0, 2 * Math.PI, false
		);
	context.fill();

	// center filler circle
	context.beginPath();
	context.arc(
		x, y + (height * 0.5),
		circleRadius / 2, 0, 2 * Math.PI, false
		);
	context.fill();

	// bottom of club
	context.moveTo(x, y + (height * 0.6));
	context.quadraticCurveTo(
		x, y + height,
		x - bottomWidth / 2, y + height
		);
	context.lineTo(x + bottomWidth / 2, y + height);
	context.quadraticCurveTo(
		x, y + height,
		x, y + (height * 0.6)
		);
	context.closePath();
	context.fill();
	context.restore();
}

function drawDiamond(context, x, y, width, height){
	context.save();
	context.fillStyle = "red";
	context.beginPath();
	context.moveTo(x, y);

	// top left edge
	context.lineTo(x - width / 2, y + height / 2);

	// bottom left edge
	context.lineTo(x, y + height);

	// bottom right edge
	context.lineTo(x + width / 2, y + height / 2);

	// closing the path automatically creates
	// the top right edge
	context.closePath();
	context.fill();
	context.restore();
}

function drawStar(ctx, x, y, r, p, m)
{
	ctx.save();
	ctx.beginPath();
	ctx.translate(x, y);
	ctx.moveTo(0,0-r);
	for (var i = 0; i < p; i++)
	{
			ctx.rotate(Math.PI / p);
			ctx.lineTo(0, 0 - (r*m));
			ctx.rotate(Math.PI / p);
			ctx.lineTo(0, 0 - r);
	}
	ctx.fill();
	ctx.restore();
}

function sortCard(cards) {
	if (cards) {
		cards.sort(function(a, b) {
			return a.rank - b.rank;
		});
	}
}
function updateCard(cards) {
	curCards = cards;
}
function updateSelectedCard(seletedCards) {

}


function updateTable(tableCards){
	preTableCards = tableCards.pre;
	curTableCards = tableCards.cur;
}

//////////  Events  \\\\\\\\\\
function handleMouseMove(event) {
	console.log(arguments.callee.name, event);
}

function handleMouseDown(event) {
	for (var i = 0; i < curLabelCards.length; i++) {
		var label = curLabelCards[i]
		selectCard(canvasCards, event, label);
	}
}

function handleMouseDownSubmit(event) {
	if (isOnLabel(canvasSubmit, event, curLabelSubmit)) {
		curLabelSubmit.callback();
	}
}

function handleMouseDownPass(event) {
	if (isOnLabel(canvasPass, event, curLabelPass)) {
		curLabelPass.callback();
	}
}

function handleMouseUp(event) {
	console.log(arguments.callee.name, event);
}

function handleResize(event) {
	drawCard();
	drawButton();
	drawTable();
	drawTableMsg();
}

function isOnLabel(canvas, event, label) {
	var x = (event.pageX - canvas.offsetLeft),
		y = (event.pageY - canvas.offsetTop);
	var leftBoundary = label.x;
	var rightBoundary = label.x + label.w;
	var upperBoundary = label.y;
	var lowerBoundary = label.y + label.h;
	if (x > leftBoundary && x < rightBoundary &&
		y > upperBoundary && y < lowerBoundary) {
		return true;
	}
	return false;
}

function selectCard(canvas, event, label) {
	if (isOnLabel(canvas, event, label)) {
		label.selected = !label.selected;
		drawSuitCard(canvas.getContext("2d"), label);
	}
}

function drawPlayerList(playersInfo) {
	curplayersInfo = playersInfo;
	createTablePlayerList();
}

function createTablePlayerList() {
	var myTableDiv = document.getElementById("playerListsDiv");
	var table = document.createElement('TABLE');
  table.id = "playerLists";
	table.classList.add("table");
	table.classList.add("table-hover");
	table.classList.add("tablePlayerLists");

	var tableHead = document.createElement('THEAD');
	tableHead.classList.add("thead-dark");
	table.appendChild(tableHead);
	// thead
	var tr = document.createElement('TR');
	tableHead.appendChild(tr);
	var th = document.createElement('TH');
	th.appendChild(document.createTextNode("Player"));
	tr.appendChild(th);

	th = document.createElement('TH');
	th.width = '52px';
	th.appendChild(document.createTextNode("C"));
	tr.appendChild(th);

	th = document.createElement('TH');
	th.width = '36px';
	th.appendChild(document.createTextNode("R"));
	tr.appendChild(th);

	th = document.createElement('TH');
	th.width = '40px';
	th.appendChild(document.createTextNode("P"));
	tr.appendChild(th);

	// tbody
	var tableBody = document.createElement('TBODY');
	table.appendChild(tableBody);

	isUserTurn = false;
	changebg_noturn();
	for (var i = 0; i < curplayersInfo.length; i++) {
		var playerInfo = curplayersInfo[i];

		tr = document.createElement('TR');
		if (playerInfo.turn == true) {
			tr.classList.add("tablePlayerTurn");
			if (username == playerInfo.name) {
				isUserTurn = true;
				changebg_myturn();
			}
		} else {
			tr.classList.add("tablePlayerNoTurn");
		}
		if (playerInfo.act == 'O')		tr.classList.add("table-info");

		tableBody.appendChild(tr);
		td = document.createElement('TD');
		td.appendChild(document.createTextNode(playerInfo.name));
		tr.appendChild(td);

		td = document.createElement('TD');
		if (playerInfo.cardCnt != false) {
			var strCardCnt = playerInfo.cardCnt.toString().concat("장");
			td.appendChild(document.createTextNode(strCardCnt));
		}
		tr.appendChild(td);

		td = document.createElement('TD');
		if (playerInfo.rank != false) td.appendChild(document.createTextNode(playerInfo.rank));
		tr.appendChild(td);

		td = document.createElement('TD');
		td.appendChild(document.createTextNode(playerInfo.point));
		tr.appendChild(td);
	}

	myTableDiv.appendChild(table);
}
createTablePlayerList();
