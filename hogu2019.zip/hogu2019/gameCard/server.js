var socketio = require("socket.io");
var gameRule = require("./rule");

var logFull = false;

// Game
var isPlaying = false;
var timerDuration = 22;
var matches = [];
// Socket io
var userList = [];
var idList = [];
// Game message
var GameMsg = {
	revolution: "대혁명!!!",
	Jrevolution: "J 혁명!",
	stop8: "8 스탑!",
	nostop8: "8 스탑저지!",
	chainSuit: "문양 묶임!",
	numberSuit: "숫자 묶임!",
	spade3: "3 스페이드!"
};

module.exports.listen = function(app) {
	io = socketio.listen(app);
  // io는 socket.io 패키지 import 변수, socket은 커넥션이 성공시 커넥션 정보
  io.on('connection', function(socket){
    var addedUser = false; // 클라이언트와 연결이 완료시

    socket.on('chat message', function(msg){
      io.emit('chat message', {
        username: socket.username,
        message: msg
      });
    });

    socket.on('disconnect', function(){
      if(!addedUser) return;

      if(idList[socket.username] === socket.id){
        var index = userList.indexOf(socket.username);
        userList.splice(index,1);

        socket.broadcast.emit('user logout',{
          username: socket.username,
          userlist: userList
        });
      }
    });// 퇴장시 유저목록에서 삭제시켜야함

    socket.on('add user',function(username){
      if(addedUser) return;

      socket.username = username;
      addedUser = true;
      // 이미 같은 아이디로 접속시
      if (userList.indexOf(username) >= 0) {
        io.to(idList[username]).emit('ban',{
          username: username,
          message: "joined by another device"
        });
      }
      else {
        userList.push(username);

        socket.broadcast.emit('user joined',{
          username: socket.username,
          userlist: userList
        }); //신규자가 왔을때 참가 메세지
      }
      idList[username] = socket.id;
      socket.emit('new people',{
        username: socket.username,
        userlist: userList
      }); //신규자가 이미 로그인 상태에서 다시 참가했을때

      var from = "admin";
      var msg = "<help>    <br>/p view players game point";
      io.to(idList[username]).emit('chat message',{
        username: from,
        message: msg
      }); // 채팅방 기본 공지

			if(matches.length > 0) {
				var match = matches[0];
				var info = gameInfoUser(match, username);
				if (info.isPlayer == true) {
					io.to(idList[username]).emit('update player cards',{
						playerCards: info.playerCards
					});
				}

				var playerList = makePlayerList(match.players);
				io.to(idList[username]).emit('update player list',{
					playersInfo: playerList,
				});

				var preCards = [];
				var curCards = match.tableCards[match.tableCards.length-1];
				if ((match.tableCards.length) >= 2) {
					preCards = match.tableCards[match.tableCards.length-2]
				}
				io.to(idList[username]).emit('update table cards',{
					pre: preCards,
					cur: curCards,
				});
				io.to(idList[username]).emit('update table status',{
					data: makeTableStatus(match)
				});
			} // 게임 차가자의 재입장시

    });// 새로 user입장시 처리하는 부분
    // ++ 유저 입장시 오른쪽 부분에 목록에 추가되어야 합니다.

    socket.on('whisper',function(data){
      var msg =data.Msg;
      var toUsername = data.To;
      var after_to = toUsername +'님에게';
      var fromUsername = socket.username;
      var after_from = fromUsername +'님의 귓속말';
      for_reciever_socket_id = idList[toUsername];
      for_sender_socket_id = idList[fromUsername];
      io.to(for_sender_socket_id).emit('chat message',{
        username: after_to,
        message: msg
      });
      io.to(for_reciever_socket_id).emit('chat message',{
        username: after_from,
        message: msg
      });
    });

    socket.on('gameStart',function(data){
      if(isPlaying) return false;
      isPlaying = true;
      io.emit('game message',{
        message: 'Game Start'
      });
			io.emit('game start');
			shuffleArray(userList);
      createMatch(data.GameTitle, userList);
    });

    socket.on('gameEnd',function(data){
      if(!isPlaying) return false;
			io.emit('game end');
      io.emit('game message',{
        message: 'Game End'
      });
      isPlaying = false;
			matches = [];
    });

		socket.on('gamePoint',function(data){
      if(!isPlaying) return false;
			var match = matches[0];
			var msg = '';
			io.emit('game message',{
				message: '*** 플레이어 포인트 ***'
			});
			for (var i = 0; i < match.players.length; i++) {
				msg = match.players[i].name.concat("(").concat(match.players[i].point).concat(")");
	      io.emit('game message',{
	        message: msg
	      });
			}
    });

		socket.on('submit card', function(data){
			if(matches.length == 0)	return;
			var match = matches[0];
			var username = data.username;
			var selectedCards = data.selectedCards;
			var isSubmitable = false;
			var cardCombi = gameRule.isCombine(selectedCards);
			var tableCombi = false;
			var curPlayerIdx = 0;
			var vsResult = falseTableResult();
			var isReady = true;

			if (match.step == 'exchange_low2high') {
				isReady = true;
				for (i = 0; i < match.players.length; i++) {
					if ((match.players[i].name == username) && (match.players[i].turn == true)) {
						if (match.card2poor === i) {
							if (selectedCards.length == 2) {
								var j = match.card2king;
								if (isValidTopk(match.players[i].cards, selectedCards, 2)) {
									match.players[i].turn = false;
									match.players[i].cards = filterCard(match.players[i].cards, selectedCards);
									appendCard(match.players[j].cards, selectedCards);

									io.to(idList[match.players[i].name]).emit('update player cards selected',{
										playerCards: match.players[i].cards,
										selectedCards: selectedCards
									});
									io.to(idList[match.players[j].name]).emit('update player cards selected',{
										playerCards: match.players[j].cards,
										selectedCards: selectedCards
									});
									var playerList = makePlayerList(match.players);
									io.emit('update player list',{
										playersInfo: playerList
									});
								}
							}
						} else if (match.card1poor === i) {
							if (selectedCards.length == 1) {
								var j = match.card1king;
								if (isValidTopk(match.players[i].cards, selectedCards, 1)) {
									match.players[i].turn = false;
									match.players[i].cards = filterCard(match.players[i].cards, selectedCards);
									appendCard(match.players[j].cards, selectedCards);

									io.to(idList[match.players[i].name]).emit('update player cards selected',{
										playerCards: match.players[i].cards,
										selectedCards: selectedCards
									});
									io.to(idList[match.players[j].name]).emit('update player cards selected',{
										playerCards: match.players[j].cards,
										selectedCards: selectedCards
									});
									playerList = makePlayerList(match.players);
									io.emit('update player list',{
										playersInfo: playerList
									});
								}
							}
						}
					}
					// check all ready
					if (match.players[i].turn === true) {
						isReady = false;
					}
				}
				if (isReady == true) {
					exchangeMatch2(match);
				}
			} // step exchange_low2high

			if (match.step == 'exchange_high2low') {
				isReady = true;
				for (i = 0; i < match.players.length; i++) {
					if ((match.players[i].name == username) && (match.players[i].turn == true)) {
						if (match.card2king === i) {
							if (selectedCards.length == 2) {
								var j = match.card2poor;
								match.players[i].turn = false;
								match.players[i].cards = filterCard(match.players[i].cards, selectedCards);
								appendCard(match.players[j].cards, selectedCards);

								io.to(idList[match.players[i].name]).emit('update player cards selected',{
									playerCards: match.players[i].cards,
									selectedCards: selectedCards
								});
								io.to(idList[match.players[j].name]).emit('update player cards selected',{
									playerCards: match.players[j].cards,
									selectedCards: selectedCards
								});
								playerList = makePlayerList(match.players);
								io.emit('update player list',{
									playersInfo: playerList
								});
							}
						} else if (match.card1king === i) {
							if (selectedCards.length == 1) {
								var j = match.card1poor;
								match.players[i].turn = false;
								match.players[i].cards = filterCard(match.players[i].cards, selectedCards);
								appendCard(match.players[j].cards, selectedCards);

								io.to(idList[match.players[i].name]).emit('update player cards selected',{
									playerCards: match.players[i].cards,
									selectedCards: selectedCards
								});
								io.to(idList[match.players[j].name]).emit('update player cards selected',{
									playerCards: match.players[j].cards,
									selectedCards: selectedCards
								});
								playerList = makePlayerList(match.players);
								io.emit('update player list',{
									playersInfo: playerList
								});
							}
						}
					}
					// check all ready
					if (match.players[i].turn === true) {
						isReady = false;
					}
				}
				if (isReady == true) {
					setTimeout(function() {
					  playMatch(match);
					}, 3000);
				}
			} // step exchange_high2low

			if (match.step == 'play') {
				if (cardCombi.isValid == false) {
					return;
				}
				for (i = 0; i < match.players.length; i++) {
					if ((match.players[i].name == username) && (match.players[i].turn == true)) {
						if (isValidPlayerCard(selectedCards, match.players[i].cards) === false) {
							io.to(idList[username]).emit('update player cards',{
								playerCards: match.players[i].cards
							});
						}
						else {
							curPlayerIdx = i;
							// check submitable cards
							if (match.tableCards.length > 0) {
								var curTableCards = match.tableCards[match.tableCards.length-1];
								if (curTableCards.length > 0) {
									tableCombi = gameRule.isCombine(match.tableCards[match.tableCards.length-1]);
									var isReverse = (match.isReverse ^ match.isTempReverse);
									var isEight = match.isTempEight;
									var chainSuits = match.chainSuits;
									var chainNum = match.chainNum;

									vsResult = vsTableCombi(cardCombi, tableCombi, isReverse, isEight, chainSuits, chainNum);
									if (vsResult.isValid == false) {
										return
									}
								}
								else {
									vsResult = new vsTableResult(true, 'play', 'next');
								} // no card on table
							}
							else {
								vsResult = new vsTableResult(true, 'play', 'next');
							} // first turn
						}	// isValidPlayerCard
					}
				}

				if (vsResult.isValid == false) {
					return;
				}

				// table cards
				match.tableCards.push(selectedCards);
				// player cards
				match.players[curPlayerIdx].cards = filterCard(match.players[curPlayerIdx].cards, selectedCards);
				io.to(idList[username]).emit('update player cards',{
					playerCards: match.players[curPlayerIdx].cards
				});

				if (vsResult.result == 'stop') {
					setInitRound(match);
				}
				else if (vsResult.result == 'play') {
					if (cardCombi.len >= 4) {
						match.isReverse = !match.isReverse;

					}
					if (cardCombi.numbers.indexOf('J') >= 0) {
						match.isTempReverse = true;

					}
					if (cardCombi.numbers.indexOf('8') >= 0) {
						match.isTempEight = !match.isTempEight;

						if (match.isTempEight == true) {
							if ( match.players[curPlayerIdx].cards.length == 0 ) {
								match.is8over = true;
							}

						}
					}
					// chain alrgoritm
					if (tableCombi) {
						// chain number
						if (Math.abs(cardNumToRank(tableCombi.max) - cardNumToRank(cardCombi.max)) == 1) {
							if (match.isReverse ^ match.isTempReverse) {
								match.chainNum = cardRankToNum(cardNumToRank(cardCombi.max) - 1)
							} else {
								match.chainNum = cardRankToNum(cardNumToRank(cardCombi.max) + 1)
							}

						}

						// chain suit
						chainSuits = tableCombi.suits.filter(function(n) {
						    return cardCombi.suits.indexOf(n) !== -1;
						});
						match.chainSuits = [...new Set(chainSuits)];


					}

					var preCards = [];
					var curCards = match.tableCards[match.tableCards.length-1];
					if ((match.tableCards.length) >= 2) {
						preCards = match.tableCards[match.tableCards.length-2];
					}
					io.emit('update table cards',{
						pre: preCards,
						cur: curCards,
					});
					io.emit('update table status',{
						data: makeTableStatus(match)
					});
				}

				if ( match.players[curPlayerIdx].cards.length == 0 ) {
					match.players[curPlayerIdx].isOver = true;
					if (isValidFinshCard(match, cardCombi) == true) {
						match.players[curPlayerIdx].rank = match.preRank;
						match.preRank++;
					} else {
						match.players[curPlayerIdx].rank = match.posRank;
						match.posRank--;
					}
					match.players[curPlayerIdx].point += (match.players.length - match.players[curPlayerIdx].rank);
					match.leftPlayers -= 1;

					if ((match.roundN > 1) && (match.preRank > 1)) {
						var kingIdx = undefined;
						if (match.players.length > 4) {
							kingIdx = match.card2king;
						} else {
							kingIdx = match.card1king;
						}

						if (match.players[kingIdx].isOver == false) {
							match.players[kingIdx].isOver = true;
							match.players[kingIdx].rank = match.posRank;
							match.posRank--;
							match.players[kingIdx].point += (match.players.length - match.players[kingIdx].rank);
							match.leftPlayers -= 1;
						}
					}
				}

				if (match.leftPlayers === 0) {
					nextMatch(match);
					return;
				}
				else if (match.leftPlayers === 1) {
					var lastTurn = getNextTurnIndex(match, curPlayerIdx);
					match.players[lastTurn].turn = false;
					match.players[lastTurn].rank = match.posRank;
					match.players[lastTurn].point += (match.players.length - match.players[lastTurn].rank);

					nextMatch(match);
					return;
				}
				else if (vsResult.turn == 'next') {
					setAllPlayersAct(match.players, false);
					match.players[curPlayerIdx].act = "O";
					match.players[curPlayerIdx].turn = false;
					nextTurn = getNextTurnIndex(match, curPlayerIdx);
					match.players[nextTurn].turn = true;

					var playerList = makePlayerList(match.players);
					io.emit('update player list',{
						playersInfo: playerList
					});
				}
			} // step play
		});

		socket.on('pass card', function(data){
			if (matches.length == 0)	return;
			var match = matches[0];
			var username = data.username;

			if (match.step == 'play') {
				if (match.tableCards.length == 0)	return;
				var curCards = match.tableCards[match.tableCards.length-1];
				if (curCards.length == 0)	return;

				var curPlayerIdx = -1;
				for (i = 0; i < match.players.length; i++) {
					if ((match.players[i].name == username) && (match.players[i].turn == true)) {
						curPlayerIdx = i;
					}
				}
				if (curPlayerIdx == -1)	return;

				var tableCombi = gameRule.isCombine(curCards);
				var nextTurn = 0;

				if (match.isTempEight == true) {
					match.players[curPlayerIdx].turn = false;
					if (match.is8over == true) {
						nextTurn = curPlayerIdx;
					} else {
						nextTurn = getPreviousTurnIndex(match, curPlayerIdx);
					}
					match.players[nextTurn].turn = true;
					setInitRound(match);
				}	else {
					// next turn
					match.players[curPlayerIdx].act = "X";
					match.players[curPlayerIdx].turn = false;
					// other players passed
					nextTurn = getNextTurnIndex(match, curPlayerIdx);
					match.players[nextTurn].turn = true;
					if (match.players[nextTurn].act != false) {
						setInitRound(match);
					}
					else {
						var playerList = makePlayerList(match.players);
						io.emit('update player list',{
							playersInfo: playerList
						});
					}
				}
			}

		});
  });
	return io;
};

function isValidFinshCard(match, cards) {
	if (cards.numbers.indexOf('joker') >= 0) {
		return false;
	}

	if (match.isReverse == true) {
		if (cards.numbers.indexOf('3') >= 0) {
			return false;
		}
	}
	else {
		if (cards.numbers.indexOf('2') >= 0) {
			return false;
		}
	}
	return true;
}

function getNextTurnIndex(match, curIdx) {
	var nextTurn = curIdx;
	for (var i = 1; i < match.players.length; i++) {
		nextTurn = (curIdx+i)%match.players.length;
		if (match.players[nextTurn].isOver == false) {
			return nextTurn;
		}
	}
	return nextTurn;
}

function getPreviousTurnIndex(match, curIdx) {
	var nextTurn = curIdx;
	for (var i = 1; i < match.players.length; i++) {
		nextTurn = (curIdx-i+match.players.length)%match.players.length;
		if (match.players[nextTurn].isOver == false) {
			return nextTurn;
		}
	}
	return nextTurn;
}

function setInitRound(match) {
	// reverse
	match.isTempReverse = false;
	match.isTempEight = false;
	match.is8over = false;
	match.chainSuits = [];
	match.chainNum = false;
	// table cards
	var preCards = match.tableCards[match.tableCards.length-1];
	var curCards = [];
	match.tableCards.push(curCards);
	io.emit('update table cards',{
		pre: preCards,
		cur: curCards,
	});
	io.emit('update table status',{
		data: makeTableStatus(match)
	});
	setAllPlayersAct(match.players, false);
	var playerList = makePlayerList(match.players);
	io.emit('update player list',{
		playersInfo: playerList
	});
}

function setAllPlayersAct(players, value) {
	for (i = 0; i < players.length; i++) {
		players[i].act = value;
	}
}

function makeTableStatus(match) {
	return {
		isTempEight: match.isTempEight,
		isTempReverse: match.isTempReverse,
		isReverse: match.isReverse,
		chainSuits: match.chainSuits,
		chainNum: match.chainNum,
		step: match.step
	}
}

function makePlayerList(players) {
	var playerList = [];
	for (var i = 0; i < players.length; i++) {
		playerList.push({
			name: players[i].name,
			turn: players[i].turn,
			cardCnt: players[i].cards.length,
			rank: players[i].rank,
			act: players[i].act,
			point: players[i].point,
			isKing: players[i].isKing,
		});
	}
	return playerList;
}

//////////  Functions  \\\\\\\\\\
// rank sort
var numbers = ["3","4","5","6","7","8","9","10","J","Q","K","A","2"];
var suits = ["club","heart","diamond","spade"];

function generateDeck() {
  deck = [];
  rank = 1;
  for (var n=0; n < numbers.length; n++) {
    for (var s=0; s < suits.length; s++) {
      deck.push({
        number: numbers[n],
        suit: suits[s],
        rank: rank++,
      });
    }
  }
  deck.push({
    number: 'joker',
    suit: 'black',
    rank: rank++
  });
  deck.push({
    number: 'joker',
    suit: 'color',
    rank: rank++
  });
  if (logFull) console.log(arguments.callee.name, deck);
	return deck;
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function shuffleDeck(deck) {
	var deckCopy = deck.slice();
	for (var i = deckCopy.length - 1; i > 0; i--) {
		var j = Math.floor(Math.random() * (i + 1));
		var temp = deckCopy[i];
		deckCopy[i] = deckCopy[j];
		deckCopy[j] = temp;
	}
  if (logFull) console.log(arguments.callee.name, deckCopy);
	return deckCopy;
}

function drawCard(deck) {
  var draw = deck.shift();
	if (logFull) console.log(arguments.callee.name, draw);
	return draw;
}

function dealInitialCards(playerObjects) {
  var deck = shuffleDeck(generateDeck());
  var n = playerObjects.length;
  var i = Math.floor(n*Math.random());
  while(deck.length){
    playerObjects[i].cards.push(drawCard(deck));
    i = (i+1)%n;
  }
	for ( i = 0; i < playerObjects.length; i++ ) {
		sortCard(playerObjects[i].cards);
	}
}

///////////////////////////////////////////////////////////////////// Create Match
function createMatch(gameTitle, participants) {
  var id = createId();
  var match = {
    matchId: id,
    title: gameTitle,
		roundN: 1,
    players: [],
		tableCards: [],
		isTempEight: false,
		is8over: false,
		isTempReverse: false,
		isReverse: false,
		chainSuits: [],
		chainNum: false,
    step: 'play',
		preRank: 1,
		posRank: participants.length,
		leftPlayers: participants.length,
    timerActive: false,
    timer: timerDuration,
		card2king: false,
		card2poor: false,
		card1king: false,
		card1poor: false
  };
  for (var i=0; i<participants.length; i++) {
    var playerObject = {
      name: participants[i],
      cards: [],
			turn: false,
      rank: 0,
			point: 0,
			act: false,
			isOver: false,
			isReady: true,
			isKing: false
    };
    match.players.push(playerObject);
  }

  dealInitialCards(match.players);

	var isSetFirstPlayer = false;
  for (i=0; i<match.players.length; i++) {
    playerName = match.players[i].name;
    playerCards = match.players[i].cards;
    playerId = idList[playerName];
    if (logFull) console.log(arguments.callee.name, playerId, playerName, playerCards);

		if (isSetFirstPlayer == false) {
			for (var j = 0; j < playerCards.length; j++) {
				if (playerCards[j].rank == 1) {
					match.players[i].turn = true;
					break;
				}
			}
		}
		io.to(playerId).emit('update player cards',{
			playerCards: playerCards
		});
  }

	var playerList = makePlayerList(match.players);
	io.emit('update player list',{
		playersInfo: playerList
	});

	io.emit('update table cards',{
		pre: [],
		cur: [],
	})
	io.emit('update table status',{
		data: makeTableStatus(match)
	});

	matches.push(match);
	match.timerActive = true;
}

///////////////////////////////////////////////////////////////////// Next Match
function createMatch_test(gameTitle, participants) {
	createMatch(gameTitle, participants);
	var match = matches[0];
	for (var i = 0; i < match.players.length; i++) {
		match.players[i].rank = i+1;
		match.players[i].point = i+90;
	}
	nextMatch(match);
}


function nextMatch(match) {
	if (match.step === 'ready') {
		return;
	}
	initMatch(match);
	// turn sort reversed by rank
	match.players.sort(function(a, b) {
		return  b.rank - a.rank;
	});

	var playerN = match.players.length;
	for (var i=0; i < playerN; i++) {
		match.players[i].isKing = false;
		if (playerN > 4) {
			if (match.players[i].rank === 1) {
				match.card2king = i;
				match.players[i].isKing = true;
			} else if (match.players[i].rank === 2) {
				match.card1king = i;
			} else if (match.players[i].rank === playerN) {
				match.card2poor = i;
			} else if (match.players[i].rank === (playerN-1)) {
				match.card1poor = i;
			}
		} else {
			if (match.players[i].rank === 1) {
				match.card1king = i;
				match.players[i].isKing = true;
			} else if (match.players[i].rank === playerN) {
				match.card1poor = i;
			}
		}
		io.to(idList[match.players[i].name]).emit('update player cards',{
			playerCards: match.players[i].cards
		});
	}

	var msg = "";
	if (match.card2king !== false) {
		msg = "대부호 : ".concat(match.players[match.card2king].name);
		io.emit('game message',{
			message: msg
		});
	}
	if (match.card1king !== false) {
		msg = "부호 : ".concat(match.players[match.card1king].name);
		io.emit('game message',{
			message: msg
		});
	}
	if (match.card1poor !== false) {
		msg = "빈민 : ".concat(match.players[match.card1poor].name);
		io.emit('game message',{
			message: msg
		});
	}
	if (match.card2poor !== false) {
		msg = "대빈민 : ".concat(match.players[match.card2poor].name);
		io.emit('game message',{
			message: msg
		});
	}

	io.emit('game message',{
		message: 'Start Next Game'
	});

	exchangeMatch1(match);
	//exchangeMatch2(match);
	//playMatch(match);
}

function exchangeMatch1(match) {
	io.emit('game card exchange');
	match.step = 'exchange_low2high';

	if (match.card2poor !== false) {
		match.players[match.card2poor].turn = true;
	}
	if (match.card1poor !== false) {
		match.players[match.card1poor].turn = true;
	}

	var playerList = makePlayerList(match.players);
	io.emit('update player list',{
		playersInfo: playerList
	});

	io.emit('game message',{
		message: 'Card Excange : Poor -> King'
	});
}

function exchangeMatch2(match) {
	match.step = 'exchange_high2low';

	if (match.card2king !== false) {
		match.players[match.card2king].turn = true;
	}
	if (match.card1king !== false) {
		match.players[match.card1king].turn = true;
	}

	var playerList = makePlayerList(match.players);
	io.emit('update player list',{
		playersInfo: playerList
	});

	io.emit('game message',{
		message: 'Card Excange : King -> Poor'
	});
}

function playMatch(match) {
	for (i=0; i < match.players.length; i++) {
		if (match.players[i].rank == match.posRank) {
			match.players[i].turn = true;
		} else {
			match.players[i].turn = false;
		}
		match.players[i].rank = 0;
	}
	var playerList = makePlayerList(match.players);
	io.emit('update player list',{
		playersInfo: playerList
	});
	match.step = 'play';
	io.emit('game play');

	var gameMsg = match.roundN.toString().concat(" Round Play Game")
	io.emit('game message',{
		message: gameMsg
	});
}

function initMatch(match) {
	match.step = 'ready';
	match.roundN += 1;
	match.tableCards = [];
	match.isTempEight = false;
	match.is8over = false;
	match.isTempReverse = false;
	match.isReverse = false;
	match.chainSuits = [];
	match.chainNum = false;
	match.isOver = false;
	match.preRank = 1;
	match.posRank = match.players.length;
	match.leftPlayers = match.players.length;
	match.timerActive = false;
	match.card2king = false;
	match.card1king = false;
	match.card2poor = false;
	match.card1poor = false;

	for (var i = 0; i < match.players.length; i++) {
		match.players[i].turn = false;
		match.players[i].act = false;
		match.players[i].isOver = false;
		match.players[i].isReady = false;
		match.players[i].cards = [];
	}

  dealInitialCards(match.players);

  for (i=0; i<match.players.length; i++) {
		io.to(playerId).emit('update player cards',{
			playerCards: match.players.cards
		});
  }

	var playerList = makePlayerList(match.players);
	io.emit('update player list',{
		playersInfo: playerList
	});

	io.emit('update table cards',{
		pre: [],
		cur: [],
	})
	io.emit('update table status',{
		data: makeTableStatus(match)
	});

	match.timerActive = true;
}


function isValidTopk(playerCards, selectedCards, k) {
	sortCard(playerCards);
	sortCard(selectedCards);
	for (var i = 0; i < k; i++) {
		if (playerCards[playerCards.length - k + i].number !== selectedCards[i].number) {
			return false;
		}
	}
	return true;
}

function createId() {
	if (logFull) console.log("%s(%j)", arguments.callee.name, Array.prototype.slice.call(arguments).sort());
	var id = "";
	var charset = "ABCDEFGHIJKLMNOPQRSTUCWXYZabcdefghijklmnopqrtsuvwxyz1234567890";
	for (var i = 0; i < 16; i++) {
		id += charset.charAt(Math.floor(Math.random() * charset.length));
	}
	return id;
}

function parse(str) {
  var args = [].slice.call(arguments, 1), i = 0;
  return str.replace(/%s/g, () => args[i++]);
}

function gameInfoUser(match, username) {
	for (i=0; i<match.players.length; i++) {
		if (match.players[i].name == username) {
			return {
				isPlayer: true,
				playerCards: match.players[i].cards
			};
		}
	}
	return {
		isPlayer: false,
		playerCards: []
	};
}

function appendCard(cards, addCards) {
	for (var i = 0; i < addCards.length; i++) {
		cards.push(addCards[i]);
	}
}

function filterCard(cards, subCards) {
	var subRanks = []
	for (var i = 0; i < subCards.length; i++) {
		subRanks.push(subCards[i].rank);
	}
	var filterdCards = cards.filter(function(x) {
		return subRanks.indexOf(x.rank) < 0;
	});
	return filterdCards;
}

function vsTableResult(isValid, result, turn) {
  this.isValid = isValid,
	this.result = result,
	this.turn = turn
}

function falseTableResult() {
  return new vsTableResult(false, false, false);
}

function vsTableCombi(combi, tableCombi, isReverse, isEight, chainSuits, chainNum) {
	if (tableCombi.max == 'joker') {
		if (tableCombi.combi == 'single') {
			if (combi.suits[0] == 'spade'  && combi.max == '3') {
				return new vsTableResult(true, 'stop', 'cur');
			}
		}
		return falseTableResult();
	}

	if (chainNum != false) {
		if ( (combi.numbers.indexOf(chainNum) < 0) && (combi.numbers.indexOf('joker') < 0) ) {
			return falseTableResult();
		}
	}

	if (chainSuits.length > 0) {
		var jokerNum = 0;
		for (var i = 0; i < combi.numbers.length; i++) {
			if (combi.numbers[i] == 'joker') {
				jokerNum++;
			}
		}
		var filterSuits = chainSuits.filter(function(n) {
				return combi.suits.indexOf(n) < 0;
		});

		if (filterSuits.length > jokerNum) {
			return falseTableResult();
		}
	}

	if (isEight == true) {
		if (combi.numbers.indexOf('8') < 0) {
			return falseTableResult();
		} else {
			if (tableCombi.combi == 'single') {
				return new vsTableResult(true, 'play', 'next');
			} else if (tableCombi.combi == 'pair') {
				if (JSON.stringify(combi.numbers)==JSON.stringify(['8','8'])) {
					return new vsTableResult(true, 'play', 'next');
				}
			}
		}
	}

	if (combi.combi != tableCombi.combi) {
		return falseTableResult();
	}
	if (combi.len != tableCombi.len) {
		return falseTableResult();
	}

	if (tableCombi.max != 'joker') {
		if (combi.max == 'joker') {
			return new vsTableResult(true, 'play', 'next');
		}
	}

	if (isReverse == true) {
		if (cardNumToRank(combi.max) >= cardNumToRank(tableCombi.max)) {
			return falseTableResult();
		}
	}
	else {
		if (cardNumToRank(combi.max) <= cardNumToRank(tableCombi.max)) {
			return falseTableResult();
		}
	}
	return new vsTableResult(true, 'play', 'next');
}

function isValidPlayerCard(submitCard, playerCard) {
	var exCards = playerCard.filter(function(x) {
		return submitCard.indexOf(x.rank) > -1
	});
	if (exCards.length === 0) {
		return true;
	}
	return false;
}

function cardNumToRank(str) {
  if (str == 'J') {
    return 11;
  }
  else if (str == 'Q') {
    return 12;
  }
  else if (str == 'K') {
    return 13;
  }
  else if (str == 'A') {
    return 14;
  }
  else if (str == '2') {
    return 15;
  }
	else if (str == 'joker') {
		return -1;
	}
  return parseInt(str);
}

function cardRankToNum(num) {
	if (num == 11) {
		return 'J'
	}
  else if (num == 12) {
    return 'Q';
  }
  else if (num == 13) {
    return 'K';
  }
  else if (num == 14) {
    return 'A';
  }
  else if (num == 15) {
    return '2';
  }
	else if (num == -1) {
		return 'joker';
	}
  return num.toString();
}

function sortCard(cards) {
	if (cards) {
		cards.sort(function(a, b) {
			return a.rank - b.rank;
		});
	}
}
