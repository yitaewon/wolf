// Chat Page
function chatShow() {
  var msg = document.getElementById("chatMsg");
  msg.style.height = "60%";
  $("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);

  var btn = document.getElementById("chatShowBtn")
  btn.value = '&#9660;'
  btn.innerHTML = '&#9660;'
  btn.onclick = chatHide;
}

function chatHide() {
  var msg = document.getElementById("chatMsg");
  msg.style.height = "25px";
  $("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);

  var btn = document.getElementById("chatShowBtn")
  btn.value = '&#9650;'
  btn.innerHTML = '&#9650;'
  btn.onclick = chatShow;
}

function showUserList(userlist) {
  $('#chatUserList').empty();
  for (var i=0; i < userlist.length; i++) {
    var dataSpan = document.createElement('span');
    dataSpan.classList.add('badge');
    dataSpan.classList.add("badge-success");
    dataSpan.style.margin = '2px';
    dataSpan.innerHTML = userlist[i];
    $('#chatUserList').append(dataSpan);
  }
}

function showRollList(rolllist) {
  $('#rollList').empty();
  var wolfteam = ['늑대인간','신비주의자 늑대','스콰이어','미니언'];
  for (var i=0; i < rolllist.length; i++) {
    var dataSpan = document.createElement('span');
    dataSpan.classList.add('badge');
    if (wolfteam.indexOf(rolllist[i]) > -1) {
      dataSpan.classList.add("badge-danger");
    } else if (rolllist[i] === '테너') {
      dataSpan.classList.add("badge-warning");
    } else if (rolllist[i] === '패밀리맨') {
      dataSpan.classList.add("badge-info");
    } else {
      dataSpan.classList.add("badge-dark");
    }

    dataSpan.style.margin = '2px';
    dataSpan.innerHTML = rolllist[i];
    $('#rollList').append(dataSpan);
  }
}

function showUserRoll(roll) {
  $('#userRoll').empty();
  $('#userRoll').append('당신의 직업:');

  var dataSpan = document.createElement('span');
  dataSpan.classList.add('badge');
  dataSpan.classList.add("badge-primary");
  dataSpan.style.margin = '2px';
  dataSpan.innerHTML = roll;
  $('#userRoll').append(dataSpan);
}

var timerID = undefined;
var userT = 0;
function setUserTimer(t) {
  userT = t-1;
  if (timerID !== undefined) {
    clearInterval(timerID);
  }
  timerID = setInterval("decrementTime()", 1000);
}

function decrementTime() {
  var userTimer = document.getElementById("userTimer");
  userTimer.innerHTML = toMinSec(userT);

  if(userT > 0) userT--;
  else {
    clearInterval(timerID);
  }
}

function toHourMinSec(t) {
  var hour;
  var min;
  var sec;

  hour = Math.floor(t / 3600);
  min = Math.floor( (t-(hour*3600)) / 60 );
  sec = t - (hour*3600) - (min*60);

  if(hour < 10) hour = "0" + hour;
  if(min < 10) min = "0" + min;
  if(sec < 10) sec = "0" + sec;

  return(hour + ":" + min + ":" + sec);
}

function toMinSec(t) {
  var min;
  var sec;

  min = Math.floor( t / 60 );
  sec = t - (min*60);

  if(min < 10) min = "0" + min;
  if(sec < 10) sec = "0" + sec;

  return(min + ":" + sec);
}
