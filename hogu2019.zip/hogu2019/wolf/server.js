var gm = require("./gameManager");
var util_common = require("../util_common");
var rooms = {};

// define constructor function that gets `io` send to it
module.exports = function(io) {
  const bluffio = io.of('/wolf');
  bluffio.on('connection', function(socket){

    socket.on('join room',function(roomId, username){
      socket.username = username;
      socket.room_id = roomId;
      socket.join(roomId); //룸입장
      console.log(socket.id, socket.username, 'connect');

      if (rooms.roomId === undefined) {
        rooms.roomId = {};
      }
      if (Object.keys(rooms.roomId).indexOf(socket.username) > -1) {
        console.log('rejoin',socket.username);
        bluffio.to(rooms.roomId[socket.username]).emit('rejoin room', {
          username: socket.username
        });
      }
      // refresh socket.id
      rooms.roomId[socket.username] = socket.id;
      bluffio.to(socket.room_id).emit('join room', {
        username: socket.username,
        userlist: Object.keys(rooms.roomId)
      });
      // refresh game info
      var gameInfo = gm.info(socket.room_id);
      if (gameInfo === undefined) return;
      bluffio.to(socket.id).emit('show rolls', {
        rolls: gameInfo.rolls
      });
      // show player roll
      var roll = gameInfo.players[socket.username].roll;
      var description = gameInfo.players[socket.username].description;
      bluffio.to(socket.id).emit('game message roll', {
        step: '당신의 직업을 선택합니다.',
        roll: roll,
        description: description
      });
    });

    socket.on('disconnect',function(){
      console.log(socket.id, socket.username, 'disconnected');
    });

    socket.on('rejoin room', function(){
      console.log('rejoin room', socket.room_id, socket.username);
    });

    socket.on('leave room', function(){
      var roomId = socket.room_id;
      if (rooms.roomId === undefined) {
        return;
      }
      if (rooms.roomId[socket.username] !== undefined) {
        rooms.roomId[socket.username] = undefined;
        delete rooms.roomId[socket.username];
      }
      bluffio.to(socket.room_id).emit('leave room', {
        username: socket.username,
        userlist: Object.keys(rooms.roomId)
      });
      socket.leave(socket.room_id);//룸퇴장
    });

    socket.on('chat message', function(msg){
      if (socket.chatEnable === false) {
        return;
      }
      //socket.broadcast.to(room_id).emit('msgAlert',data); //자신 제외 룸안의 유저
      //socket.in(room_id).emit('msgAlert',data); //broadcast 동일하게 가능 자신 제외 룸안의 유저
      //io.of('namespace').in(room_id).emit('msgAlert', data) //of 지정된 name space의 유저의 룸
      bluffio.to(socket.room_id).emit('chat message', {
        username: socket.username,
        message: msg
      });
    });

    socket.on('chat disable', function(){
      socket.chatEnable = false;
    });
    socket.on('chat enable', function(){
      socket.chatEnable = true;
    });


    socket.on('game vote', function(data){
      var gameInfo = gm.info(socket.room_id);
      if (gameInfo === undefined) return;
      var msg;
      gameInfo.players[socket.username].vote = data.vote;

      if (gameInfo.allPlayers.indexOf(data.vote) === -1) {
        msg = '['.concat(data.vote).concat(']는 잘못된 플레이어 이름입니다.');
        bluffio.to(rooms.roomId[socket.username]).emit('game message', {
          message: msg
        });
      } else if (socket.username === data.vote) {
        msg = '자신에게는 투표할 수 없습니다.';
        bluffio.to(rooms.roomId[socket.username]).emit('game message', {
          message: msg
        });
      } else {
        msg = '['.concat(data.vote).concat(']에게 투표하셨습니다.');
        bluffio.to(rooms.roomId[socket.username]).emit('game message', {
          message: msg
        });
      }
    });

    socket.on('game start', function() {
      socket.chatEnable = false;

      var roomId = socket.room_id;
      if (rooms.roomId === undefined) {
        rooms.roomId = {};
      }
      var users = Object.keys(rooms.roomId);
      gm.start(roomId, users);

      var gameInfo = gm.info(roomId);
      if (gameInfo === undefined) return;

      msg = '자리배치 : ['.concat(gameInfo.allPlayers.join(',')).concat(']');
      bluffio.to(socket.room_id).emit('game message', {
        message: msg
      });

      // show roll list
      bluffio.to(socket.room_id).emit('show rolls', {
        rolls: gameInfo.rolls
      });
      bluffio.to(socket.room_id).emit('set timer', {
        step: '한밤의 늑대인간',
        time: 0
      });
      // show player roll
      for (var playerName in gameInfo.players) {
        var roll = gameInfo.players[playerName].roll;
        var description = gameInfo.players[playerName].description;
        bluffio.to(rooms.roomId[playerName]).emit('game message roll', {
          step: '당신의 직업을 선택합니다.',
          roll: roll,
          description: description
        });
      }
      // game start alert
      bluffio.to(socket.room_id).emit('game start');

      // game roll steps
      var gameRoll, randomIdx, msg;
      var gamePlayTime = 0;
      var gameStepTime = 10;
      // 늑대 확인
      setTimeout(function() {
        GameStep_ChkWerewolf(bluffio, socket, gameInfo);
      }, gamePlayTime*1000);
      gamePlayTime += gameStepTime;
      for (var i in gameInfo.rolls) {
        gameRoll = gameInfo.rolls[i];
        if (gameRoll == '늑대인간') {
          setTimeout(function() {
            GameStep_werewolf(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '신비주의자 늑대') {
          setTimeout(function() {
            GameStep_misticwolf(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '미니언') {
          setTimeout(function() {
            GameStep_minion(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '띵') {
          setTimeout(function() {
            GameStep_thing(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '씨어') {
          setTimeout(function() {
            GameStep_seer(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '로버') {
          setTimeout(function() {
            GameStep_robber(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '인썸니아') {
          setTimeout(function() {
            GameStep_insomniac(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '트러블메이커') {
          setTimeout(function() {
            GameStep_troublemaker(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '아우라 씨어') {
          setTimeout(function() {
            GameStep_auraseer(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '드렁큰') {
          setTimeout(function() {
            GameStep_Drunken(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '스콰이어') {
          setTimeout(function() {
            GameStep_Squire(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '비홀더') {
          setTimeout(function() {
            GameStep_Beholder(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        } else if (gameRoll === '패밀리맨') {
          setTimeout(function() {
            GameStep_familyman(bluffio, socket, gameInfo);
          }, gamePlayTime*1000);
          gamePlayTime += gameStepTime;
        }
      } //게임 진행
      bluffio.to(socket.room_id).emit('set timer', {
        step: '밤이 되었습니다.',
        time: gamePlayTime
      });

      // 토론 준비
      var t_ready = 10;
      var t_discuss = 360;
      var t_vote = 10;

      setTimeout(function() {
        GameReady(bluffio, socket, t_ready);
      }, gamePlayTime*1000);
      gamePlayTime += t_ready;
      setTimeout(function() {
        GameDiscuss(bluffio, socket, t_discuss);
      }, gamePlayTime*1000);
      gamePlayTime += t_discuss;
      setTimeout(function() {
        GameVote(bluffio, socket, t_ready);
      }, gamePlayTime*1000);
      gamePlayTime += t_vote;
    }); // game start

    socket.on('game result', function() {
      // game end
      bluffio.to(socket.room_id).emit('game result');

      var gameInfo = gm.info(socket.room_id);
      if (gameInfo === undefined) return;

      var msg, roll, lastRoll, vote, isVote = true;
      var voteResults = {};
      var noVotePlayers = [];
      for (var playerName in gameInfo.players) {
        if (gameInfo.players[playerName].vote === false) {
          noVotePlayers.push(playerName);
        }
      }
      if (noVotePlayers.length > 0) {
        msg = '['.concat(noVotePlayers.join(',')).concat('] 가 아직 투표를 하지 않았습니다.');
        bluffio.to(socket.room_id).emit('game message', {
          message: msg
        });
      } else {
        for (var playerName in gameInfo.players) {
          roll = gameInfo.players[playerName].roll;
          lastRoll = gameInfo.players[playerName].lastRoll;
          vote = gameInfo.players[playerName].vote;
          msg = playerName.concat(' : ').concat(roll).concat(' -> ').concat(lastRoll).concat(' / 투표 : ').concat(vote);
          bluffio.to(socket.room_id).emit('game message', {
            message: msg
          });
          if (voteResults[vote] === undefined) {
            voteResults[vote] = 0;
          }
          voteResults[vote] += 1;
        }

        bluffio.to(socket.room_id).emit('game message step', {
          step: '*** 투표 결과 ***'
        });
        for (var votePlayer in voteResults) {
          if (gameInfo.players[votePlayer] === undefined) continue;
          lastRoll = gameInfo.players[votePlayer].lastRoll;
          msg = votePlayer.concat('[').concat(lastRoll).concat('] : ').concat(voteResults[votePlayer]).concat('표');
          bluffio.to(socket.room_id).emit('game message', {
            message: msg
          });
        }
      }
    });

    socket.on('game end', function() {
      // game end
      bluffio.to(socket.room_id).emit('game end');
      gm.end(socket.room_id);
    });
  }); // io connection
};

function GameStep_ChkWerewolf(bluffio, socket, gameInfo) {
  var msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '늑대인간은 서로를 확인합니다.'
  });
  msg = '늑대인간은 ['.concat(gameInfo.wolfPlayers.join(',')).concat('] 입니다.');
  for (i=0; i<gameInfo.wolfPlayers.length; i++) {
    playerName = gameInfo.wolfPlayers[i];
    bluffio.to(rooms.roomId[playerName]).emit('game message', {
      message: msg
    });
  }
}

function GameStep_werewolf(bluffio, socket, gameInfo) {
  var randomIdx, msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '늑대인간은 혼자인 경우 가운데 카드 한장을 확인합니다.'
  });

  if (gameInfo.werewolf !== undefined) {
    if (gameInfo.wolfPlayers.length === 1) {
      gameInfo.nightActivePlayers.push(gameInfo.werewolf);
      randomIdx = Math.floor(gameInfo.midCards.length*Math.random());
      roll = gameInfo.midCards[randomIdx];
      msg = '[가운데 카드'.concat(randomIdx+1).concat(']는 ').concat('[').concat(roll).concat('] 입니다.');
      bluffio.to(rooms.roomId[gameInfo.werewolf]).emit('game message', {
        message: msg
      });
    }
  }

  if (gameInfo.mysticWerewolf !== undefined) {
    if (gameInfo.wolfPlayers.length === 1) {
      randomIdx = Math.floor(gameInfo.midCards.length*Math.random());
      roll = gameInfo.midCards[randomIdx];
      msg = '[가운데 카드'.concat(randomIdx+1).concat(']는 ').concat('[').concat(roll).concat('] 입니다.');
      bluffio.to(rooms.roomId[gameInfo.mysticWerewolf]).emit('game message', {
        message: msg
      });
    }
  }
}

function GameStep_misticwolf(bluffio, socket, gameInfo) {
  var randomIdx, msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '신비주의자 늑대는 다른 사람의 카드 한장을 확인합니다.'
  });

  if (gameInfo.mysticWerewolf !== undefined) {
    gameInfo.nightActivePlayers.push(gameInfo.mysticWerewolf);
    randomIdx = Math.floor(gameInfo.noWolfPlayers.length*Math.random());
    playerName = gameInfo.noWolfPlayers[randomIdx];
    roll = gameInfo.players[playerName].lastRoll;
    msg = '['.concat(playerName).concat(']는 ').concat('[').concat(roll).concat('] 입니다.');
    bluffio.to(rooms.roomId[gameInfo.mysticWerewolf]).emit('game message', {
      message: msg
    });
  }
}

function GameStep_minion(bluffio, socket, gameInfo) {
  var msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '미니언은 늑대인간들을 확인합니다.'
  });

  if (gameInfo.minion !== undefined) {
    if (gameInfo.wolfPlayers.length === 0) {
      msg = '늑대인간은 없습니다.';
    } else {
      msg = '늑대인간은 ['.concat(gameInfo.wolfPlayers.join(',')).concat('] 입니다.');
    }
    bluffio.to(rooms.roomId[gameInfo.minion]).emit('game message', {
      message: msg
    });
  }
}

function GameStep_Squire(bluffio, socket, gameInfo) {
  var msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '스콰이어는 늑대인간들과 그들의 최종직업을 확인합니다.'
  });

  if (gameInfo.squire !== undefined) {
    if (gameInfo.wolfPlayers.length === 0) {
      msg = '늑대인간은 없습니다.';
      bluffio.to(rooms.roomId[gameInfo.squire]).emit('game message', {
        message: msg
      });
    } else {
      gameInfo.nightActivePlayers.push(gameInfo.squire);
      for (i=0; i<gameInfo.wolfPlayers.length; i++) {
        var playerName = gameInfo.wolfPlayers[i];
        roll = gameInfo.players[playerName].lastRoll;
        msg = '늑대인간은 ['.concat(playerName).concat(']이고, 최종직업은 ').concat('[').concat(roll).concat('] 입니다.');
        bluffio.to(rooms.roomId[gameInfo.squire]).emit('game message', {
          message: msg
        });
      }
    }
  }
}

function GameStep_Beholder(bluffio, socket, gameInfo) {
  var msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '비홀더는 씨어, 견습씨어와 그들의 최종직업을 확인합니다.'
  });

  if (gameInfo.beholder !== undefined) {
    if (gameInfo.seerPlayers.length === 0) {
      msg = '씨어는 없습니다.';
      bluffio.to(rooms.roomId[gameInfo.beholder]).emit('game message', {
        message: msg
      });
    } else {
      gameInfo.nightActivePlayers.push(gameInfo.beholder);
      for (i=0; i<gameInfo.seerPlayers.length; i++) {
        var playerName = gameInfo.seerPlayers[i];
        roll = gameInfo.players[playerName].lastRoll;
        msg = '씨어는 ['.concat(playerName).concat(']이고, 최종직업은 ').concat('[').concat(roll).concat('] 입니다.');
        bluffio.to(rooms.roomId[gameInfo.beholder]).emit('game message', {
          message: msg
        });
      }
    }
  }
}

function GameStep_thing(bluffio, socket, gameInfo) {
  var randomIdx, playerName, roll, msg1, msg2;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '띵은 자신의 오른쪽 혹은 왼쪽에 있는 사람에게 가까운 쪽 어깨를 살짝 건듭니다.'
  });

  if (gameInfo.thing !== undefined) {

    if (Math.random() < 0.5) {
      randomIdx = (gameInfo.allPlayers.indexOf(gameInfo.thing) + 1) % gameInfo.allPlayers.length;
    } else {
      randomIdx = (gameInfo.allPlayers.indexOf(gameInfo.thing) + gameInfo.allPlayers.length - 1) % gameInfo.allPlayers.length;
    }
    playerName = gameInfo.allPlayers[randomIdx];

    msg1 = '['.concat(playerName).concat(']의 어깨를 살짝 건드립니다.');
    bluffio.to(rooms.roomId[gameInfo.thing]).emit('game message', {
      message: msg1
    });
    msg2 = '['.concat(gameInfo.thing).concat(']가 당신의 어깨를 살짝 건드립니다.');
    bluffio.to(rooms.roomId[playerName]).emit('game message', {
      message: msg2
    });
  }
}

function GameStep_seer(bluffio, socket, gameInfo) {
  var randomIdx, playerName, roll, msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '씨어는 가운데 카드 2장 혹은 다른 사람의 카드 한장을 확인합니다.'
  });
  if (gameInfo.seer !== undefined) {
    gameInfo.nightActivePlayers.push(gameInfo.seer);
    if (Math.random() < 0.5) {
      randomIdx = Math.floor(gameInfo.allPlayers.length*Math.random());
      playerName = gameInfo.allPlayers[randomIdx];
      if (playerName === gameInfo.seer) {
        randomIdx = (randomIdx+1) % gameInfo.allPlayers.length;
        playerName = gameInfo.allPlayers[randomIdx];
      }
      roll = gameInfo.players[playerName].lastRoll;
      msg = '['.concat(playerName).concat(']는 ').concat('[').concat(roll).concat('] 입니다.');
      bluffio.to(rooms.roomId[gameInfo.seer]).emit('game message', {
        message: msg
      });
    } else {
      randomIdx = Math.floor(gameInfo.midCards.length*Math.random());
      roll = gameInfo.midCards[randomIdx];
      msg = '[가운데 카드'.concat(randomIdx+1).concat(']는 ').concat('[').concat(roll).concat('] 입니다.');
      bluffio.to(rooms.roomId[gameInfo.seer]).emit('game message', {
        message: msg
      });
      var randomIdxTmp = Math.floor(gameInfo.midCards.length*Math.random());
      if (randomIdx === randomIdxTmp) {
        randomIdx = (randomIdxTmp+1) % gameInfo.midCards.length;
      } else {
        randomIdx = randomIdxTmp;
      }
      roll = gameInfo.midCards[randomIdx];
      msg = '[가운데 카드'.concat(randomIdx+1).concat(']는 ').concat('[').concat(roll).concat('] 입니다.');
      bluffio.to(rooms.roomId[gameInfo.seer]).emit('game message', {
        message: msg
      });
    }
  }
}

function GameStep_robber(bluffio, socket, gameInfo) {
  var randomIdx, msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '로버는 다른 사람의 카드 한장과 바꾼 후 그 카드를 확인합니다.'
  });

  if (gameInfo.robber !== undefined) {
    gameInfo.nightActivePlayers.push(gameInfo.robber);
    randomIdx = Math.floor(gameInfo.allPlayers.length*Math.random());
    playerName = gameInfo.allPlayers[randomIdx];
    if (playerName === gameInfo.robber) {
      randomIdx = (randomIdx+1) % gameInfo.allPlayers.length;
      playerName = gameInfo.allPlayers[randomIdx];
    }
    roll = gameInfo.players[playerName].lastRoll;
    msg = '로버는 ['.concat(playerName).concat(']의 직업 ').concat('[').concat(roll).concat('] 와 바꿉니다.');
    bluffio.to(rooms.roomId[gameInfo.robber]).emit('game message', {
      message: msg
    });
    // swap roll
    [gameInfo.players[playerName].lastRoll, gameInfo.players[gameInfo.robber].lastRoll] = [gameInfo.players[gameInfo.robber].lastRoll,  gameInfo.players[playerName].lastRoll];
  }
}

function GameStep_troublemaker(bluffio, socket, gameInfo) {
  var randomIdx, msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '트러블메이커는 자신을 제외한 다른 사람의 카드 2장을 서로 바꿉니다.'
  });

  if (gameInfo.troublemaker !== undefined) {
    gameInfo.nightActivePlayers.push(gameInfo.troublemaker);
    var rangeArray = Array.from(Array(gameInfo.allPlayers.length).keys());
    var randomArray = util_common.shuffleArray(rangeArray);
    var playerName1 = gameInfo.allPlayers[randomArray[0]];
    var playerName2 = gameInfo.allPlayers[randomArray[1]];
    if (playerName1 === gameInfo.troublemaker) {
      playerName1 = gameInfo.allPlayers[randomArray[2]];
    }
    if (playerName2 === gameInfo.troublemaker) {
      playerName2 = gameInfo.allPlayers[randomArray[2]];
    }
    msg = '['.concat(playerName1).concat('] 와 ').concat('[').concat(playerName2).concat('] 의 카드를 바꿉니다.');
    bluffio.to(rooms.roomId[gameInfo.troublemaker]).emit('game message', {
      message: msg
    });
    // swap roll
    [gameInfo.players[playerName1].lastRoll, gameInfo.players[playerName2].lastRoll] = [gameInfo.players[playerName2].lastRoll,  gameInfo.players[playerName1].lastRoll];
  }
}

function GameStep_familyman(bluffio, socket, gameInfo) {
  var randomIdx, msg;
  randomIdx = Math.floor(4*Math.random());
  if (randomIdx === 0) {
    msg = "패밀리맨은 일어나서 왼쪽 두명을 쳐다봅니다. 그사람이 가족입니다. 패밀리맨은 자신과 가족을 지켜야만 승리합니다.";
  } else if (randomIdx === 1) {
    msg = "패밀리맨은 일어나서 왼쪽 한명을 쳐다봅니다. 그사람이 가족입니다. 패밀리맨은 자신과 가족을 지켜야만 승리합니다.";
  } else if (randomIdx === 2) {
    msg = "패밀리맨은 일어나서 오른쪽 두명을 쳐다봅니다. 그사람이 가족입니다. 패밀리맨은 자신과 가족을 지켜야만 승리합니다.";
  } else if (randomIdx === 3) {
    msg = "패밀리맨은 일어나서 오른쪽 한명을 쳐다봅니다. 그사람이 가족입니다. 패밀리맨은 자신과 가족을 지켜야만 승리합니다.";
  }
  bluffio.to(socket.room_id).emit('game message', {
    message: msg
  });
}

function GameStep_insomniac(bluffio, socket, gameInfo) {
  var playerName, roll, msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '인썸니아는 자신의 카드를 확인합니다.'
  });

  if (gameInfo.insomniac !== undefined) {
    gameInfo.nightActivePlayers.push(gameInfo.insomniac);
    playerName = gameInfo.insomniac;
    roll = gameInfo.players[playerName].lastRoll;
    msg = '자신의 직업은 '.concat('[').concat(roll).concat('] 입니다.');
    bluffio.to(rooms.roomId[gameInfo.insomniac]).emit('game message', {
      message: msg
    });
  }
}

function GameStep_Drunken(bluffio, socket, gameInfo) {
  var randomIdx, roll, msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '드렁큰은 가운데 카드 3장 중 하나와 자신의 카드를 바꿉니다.'
  });

  if (gameInfo.drunken !== undefined) {
    gameInfo.nightActivePlayers.push(gameInfo.drunken);
    randomIdx = Math.floor(gameInfo.midCards.length*Math.random());
    roll = gameInfo.midCards[randomIdx];
    msg = '[가운데 카드'.concat(randomIdx+1).concat('] 와 바꿉니다.');
    bluffio.to(rooms.roomId[gameInfo.drunken]).emit('game message', {
      message: msg
    });
    // swap roll
    [gameInfo.players[gameInfo.drunken].lastRoll, gameInfo.midCards[randomIdx]] = [gameInfo.midCards[randomIdx],gameInfo.players[gameInfo.drunken].lastRoll];
  }
}


function GameStep_auraseer(bluffio, socket, gameInfo) {
  var randomIdx, msg;
  bluffio.to(socket.room_id).emit('game message step', {
    step: '아우라 씨어는 밤에 카드를 움직이거나 확인한 적이 있는 모든 사람을 확인합니다.'
  });

  if (gameInfo.auraseer !== undefined) {
    if (gameInfo.nightActivePlayers.length === 0) {
      msg = '밤에 행동한 사람이 없습니다.';
    } else {
      msg = '밤에 행동한 사람은 ['.concat(gameInfo.nightActivePlayers.join(',')).concat('] 입니다.');
    }
    bluffio.to(rooms.roomId[gameInfo.auraseer]).emit('game message', {
      message: msg
    });
  }
}

function GameReady(bluffio, socket, t_ready) {
  bluffio.to(socket.room_id).emit('game message step', {
    step: '토론을 준비합니다. (대화금지)'
  });
  bluffio.to(socket.room_id).emit('set timer', {
    step: '토론 준비',
    time: t_ready
  });
}

function GameDiscuss(bluffio, socket, t_discuss) {
    // 토론 시작
    bluffio.to(socket.room_id).emit('game message step', {
      step: '토론을 시작합니다. (대화가능)'
    });
    bluffio.to(socket.room_id).emit('set timer', {
      step: '토론 시간',
      time: t_discuss
    });
    bluffio.to(socket.room_id).emit('game discuss');
}

function GameVote(bluffio, socket, t_vote) {
  bluffio.to(socket.room_id).emit('game message step', {
    step: '투표를 시작합니다. (/v 유저이름)'
  });
  var msg = "2표 이상의 투표를 받으면 죽는다.(자신에게 투표불가)<br><마을사람 팀 승리 조건><br>1.늑대인간이 존재하는 경우: 늑대인간이 하나 이상 죽어야 한다.<br>2.늑대인간이 존재하지 않으나, 미니언(스콰이어)은 존재하는 경우: 미니언(스콰이어)을 죽여야 한다.<br>3.늑대인간/미니언(스콰이어)이 모두 존재하지 않는 경우: (서로에게 1표씩 투표하여서) 아무도 죽지 않아야 한다.<br>4.테너의 사망 여부는 마을 팀의 승리 여부와 무관하다.<br><늑대인간 팀 승리 조건><br>1.늑대인간 중 누구도 죽지 않는다. 늑대인간이 존재시에 죽지않고 미니언(스콰이어) 혼자 죽게되면 늑대팀이 승리한다.<br>2.테너가 존재하는 경우, 테너는 살아있어야 한다.<br>3.미니언(스콰이어)이 혼자 존재하는 경우, 미니언(스콰이어)은 살아있어야 한다.<br><테너 승리 조건><br>자신이 죽으면 승리한다.";
  bluffio.to(socket.room_id).emit('game message', {
    message: msg
  });
  bluffio.to(socket.room_id).emit('set timer', {
    step: '투표 시간',
    time: t_vote
  });
  bluffio.to(socket.room_id).emit('game vote', {
    time: t_vote
  });
}
