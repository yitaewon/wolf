const socket = io('/wolf');

// join room
socket.emit('join room',roomId,username);

$('form').submit(function(){
	if($('#chatInput').val()[0]==='/'){
		if($('#chatInput').val()[1]==='s'){
			socket.emit('game start');
			$('#chatInput').val('');
		}
		else if($('#chatInput').val()[1]==='e'){
			socket.emit('game end');
			$('#chatInput').val('');
		}
		else if($('#chatInput').val()[1]==='r'){
			socket.emit('game result');
			$('#chatInput').val('');
		}
		else if($('#chatInput').val()[1]==='c'){
			socket.emit('game continue');
			$('#chatInput').val('');
		}
		else if($('#chatInput').val()[1]==='v'){
			var vote = $('#chatInput').val().substring(3);
			socket.emit('game vote', {
				vote: vote
			});
			$('#chatInput').val('');
		}
	}
	else if($('#chatInput').val()===''){
		return false;
	}
	else{
  	socket.emit('chat message', $('#chatInput').val());
  	$('#chatInput').val('');
	}
	return false;
}); //client에서 server로 msg 전송

socket.on('game next', function() {
	socket.emit('game continue');
});

socket.on('join room', function(data) {
	var span = $('<span class="nickname">').text(data.username).append(' ');
	var li = $('<li>').append(span).append('joined').css('color', getColor(data.username));
	$('#chatMsg').append(li);
	$("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);

	showUserList(data.userlist);
}); //user join

socket.on('rejoin room', function() {
	socket.emit('rejoin room');
	window.location.href = '/game_list';
});

function chatLeave() {
	socket.emit('leave room');
	window.location.href = '/game_list';
}

socket.on('leave room', function(data) {
	var span = $('<span class="nickname">').text(data.username).append(' ');
	var li = $('<li>').append(span).append('leaved').css('color', getColor(data.username));
	$('#chatMsg').append(li);
	$("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);

	showUserList(data.userlist);
}); //user leave

socket.on('game start', function() {
	soundScaryNight();
	socket.emit('chat disable');
});

socket.on('game discuss', function() {
	socket.emit('chat enable');
});

socket.on('game vote', function(date) {
	socket.emit('chat disable');
});

socket.on('game result', function() {
	soundPause();
	socket.emit('chat enable');
});

socket.on('game end', function() {
	soundPause();
	socket.emit('chat enable');
});

socket.on('show rolls', function(data) {
	showRollList(data.rolls);
});

socket.on('set timer', function(data) {
  var gameStep = document.getElementById("gameStep");
  gameStep.innerHTML = data.step;
	setUserTimer(data.time);
});

socket.on('chat message', function(data){
	var span = $('<span class="nickname">').text(data.username).append(' : ');
	var li = $('<li>').append(span).append(data.message).css('color', getColor(data.username));
	$('#chatMsg').append(li);
	$("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);
}); //chat 내용을 채팅창에 출력

socket.on('chat message bluff', function(data){
	var span = $('<span class="nickname">').text(data.username).append(' : ');
	var li = $('<li>').append(span).append('bluff!!!').css('color', getColor(data.username));
	$('#chatMsg').append(li);
	$("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);
}); //chat 내용을 채팅창에 출력

socket.on('game message', function(data){
	var li = $('<li>').css('font-weight','bold').css('color', COLORS_HL).append(data.message);
	$('#chatMsg').append(li);
	$("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);
}); //chat 내용을 채팅창에 출력

socket.on('game message roll', function(data){
	var span = $('<span class="nickname">').text('[Game Manager]').append(' ').append(data.step);
	var li = $('<li>').append(span).css('color', COLORS_GM);
	$('#chatMsg').append(li);
	var job = $('<li>').append('직업 : ').append(data.roll).css('color', COLORS_HL).css('font-weight','bold');
	$('#chatMsg').append(job);
	var desc = $('<li>').append('설명 : ').append(data.description).css('color', COLORS_HL).css('font-weight','bold');
	$('#chatMsg').append(desc);
	$("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);

	showUserRoll(data.roll);
});

socket.on('game message step', function(data){
	var li = $('<li>').css('color', COLORS_GM).append(' - ').append(data.step);
	$('#chatMsg').append(li);
	$("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);
});

var COLORS_GM = "#000000";
var COLORS_HL = "#A43060";
var COLORS = [
	'#e21400', '#91580f', '#f8a700', '#f78b00',
	'#58dc00', '#287b00', '#a8f07a', '#4ae8c4',
	'#3b88eb', '#3824aa', '#a700ff', '#d300e7'
];
var USERCOLORS = {
	elca: '#8b00ff',
	강날두: '#d45cda',
	푸어맨: '#E8B760',
	자오기: '#0000FF',
	가라마: '#FF0000',
	퓨먀: '#000000'
}

function getColor(username){
	if (USERCOLORS[username] !== undefined) {
		return USERCOLORS[username];
	}
	var hash = 7;
	for (var i = 0; i < username.length; i++) {
		 hash = username.charCodeAt(i) + (hash << 5) - hash;
	}
	var index = Math.abs(hash % COLORS.length);
	return COLORS[index];
}// 이름에 색칠 정해주기
