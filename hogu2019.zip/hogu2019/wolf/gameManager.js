/*
0. 센티넬 (수호자)
자신을 제외한 한 명에게 방패 토큰을 줄 수 있다. 방패 토큰을 받은 사람의 카드는 다른 사람이 보거나 이동할 수 없다. (예를 들어, 씨어가 해당 카드를 볼 수 없으며, 문제아가 해당 카드를 바꿀 수 없다.)

1. 도플갱어
차례가되면 다른 캐릭터를 보고 그 캐릭터의 능력을 복제한다.
그리고 복제한 캐릭의 팀에 소속된다. 씨어, 로버, 트러블메이커, 드렁큰가 됐을 시 바로 그 능력을 사용한다.
인썸니아를 복제했을때는 마지막 인썸니아 다음에 자기 직업을 확인한다.
2. 웨어울프 (늑대인간)
자신의 차례때 눈을 떠 다른 늑대인간을 확인한다. 만약 자신 혼자 늑대인간 일 경우는 가운데 카드 중 한장을 확인 할 수 있다.
생각보다 어려운 직업으로 승리하기 위해서 상황을 빠르게 파악하고 적절하게 다른 직업을 사칭하며 행동하는 순간대처능력이 중요하다.
기본적으로 마피아게임처럼 하면 되지만, 일단 테너랑 미니언이 들어가면 내가 늑대인간이야! 라고 진실된 외침을 외쳐도 안믿는다.
그러니 정 답이 없어 보이면 늑대인간이라고 나서도 된다.

2B. 알파 울프 (대장 늑대)
늑대인간으로 취급한다. 이후에 혼자 일어나서 중앙에 놓여 있는 늑대인간 카드를 늑대인간이 아닌 플레이어와 바꿔서 새로운 늑대인간을 반드시 만든다. (즉 다른 늑대인간들은 바뀌어진 늑대인간이 누군지 알 수 없다.)
늑대 인간이 늘어나기 때문에, 자칫하면 늑대 인간이 걸릴 확률만 늘려주는 직업. 늑대 인간이 늘어나서 늑대 인간에게 유리한 직업인 듯 하지만, 이로 인해 투표 당하면 지는 대상자들이 많아지고, 더욱이 일부 직업은 알파 울프가 주려는 가운데 카드를 볼 수도 있어서 불리해 지는 느낌이 있다.

2C. 미스틱 울프 (신비주의자 늑대)
늑대 인간으로 취급한다. 이후에 혼자 일어나서 다른 플레이어 한 명의 직업을 볼 수 있다. 즉 씨어와 늑대인간의 혼합.

3. 미니언 (미니언)
자신의 차례때 늑대인간이 누군지 확인 할 수 있다. 늑대인간은 엄지 손가락을 들어 확인시킨다. (단 늑대인간은 부하를 모른다.)
테너와 함께 게임을 빛내는 주역. 미니언이 죽어도 늑대인간은 이기기 때문에 자신이 나서서 대신 죽는 전략도 좋은 방법이다.
4. 프리메이슨 (비밀 요원)
자신의 차례때 눈을 떠서 다른 비밀 요원을 확인한다. (이로 인해 비밀 요원 카드는 기본적으로 2장을 한번에 집어넣는다.)
혼자 눈을 뜬 경우, 가운데 카드 중 하나가 비밀 요원이라고 생각하면 된다.
5. 시어 (씨어)
가운데 놓여진 카드 3장 중 2장을 보거나 다른 사람의 카드 한 장을 볼 수 있다.
정보가 가장 많은 직업인 만큼 가장 의심을 많이 받는다.
또 늑대인간도 한명일 때는 가운데 카드를 뒤집어 볼 수 있기 때문에 씨어라고 주장하기도 한다.
가끔 로버가 씨어를 자처하는 트롤링이 나오기도한다.
6. 로버 (로버)
다른 사람의 카드와 자신의 카드를 바꾼 후 바꾼 카드를 확인할 수 있다. (이때 그 사람의 능력을 쓰진 못 한다.)
직업 변경 이후에도 자신의 정체를 안다는 점에서 강점인 캐릭터. 단 트러블메이커에게 당하면...
7. 트러블메이커 (트러블메이커)
다른 두 사람의 카드를 서로 바꾼다. 다만 카드 내용을 확인할 수는 없다.
이 게임의 꽃으로 문제아가 누구를 바꿨는지 말하자 마자 게임이 종료되는 경우도 많다.
트러블메이커가 늑대인간이나 미니언을 다른 직업으로 바꿔버렸다는 사실이 알려지면 그들이 배신할 수도 있기 때문.
물론 트러블메이커가 떠보기 식으로 거짓말을 할 수도 있으므로 주의하여야 한다.

7C. 아우라 씨어 (영기 씨어)
영기 씨어가 눈을 떴을 때 카드를 움직이거나 확인한 적이 있는 모든 사람은 엄지손가락을 치켜세워야 한다. 단, 밤에 행동이 선택 행동이며, 행동을 하지 않은 경우 치켜세우면 안된다. 해당 직업은 아래와 같다.
(본판): 도플갱어, 외로운 늑대 인간, 씨어, 로버, 문제아
(데이브레이크): 알파 울프, 미스틱 울프, P.I., 마녀, 동네 바보
(뱀파이어): 명사수, 카피캣

8. 드렁크 (드렁큰)
가운데 카드 3장 중 하나와 자신의 카드를 반드시 바꾼다. (이때 바꾼카드를 볼 수 없다.) 씨어, 로버, 트러블메이커의 행동은 선택사항인 반면 드렁큰의 행동은 반드시 해야하는 필수행동이다.
자기 직업을 모른다는 특성 때문에 트롤을 하거나 조용히 있거나 둘 중 하나밖에 못하는 캐릭터.
천리안(씨어)이 가운데 카드 2장 말해주면 자기 직업을 조금 추측할 수 있다.
9. 인섬니아 (인썸니아)
자신의 차례때 자신의 카드를 다시 확인한다.
어찌보면 시민측 최종보스. 이 게임을 한 사람들의 대다수가 최고의 캐릭터로 꼽을만큼 사기성이 짙다.

10. 리빌러 (폭로자)
카드 한 장을 골라서 뒤집는다. 늑대나 테너가 아니라면 뒤집은 카드를 공개된 채로 놔두고, 늑대나 테너 (그리고 뱀파이어)가 나오면 다시 엎어 논다.

11. 큐레이터 (학예사)
유물토큰 하나를 원하는 사람(본인 포함)의 카드 위에 올려준다. 단, 유물토큰이 뭔지 모르게 엎어놓은 상태로 줘야 한다. 대부분의 토큰은 직업을 바꾸나, 일부 토큰은 다른 효과를 불러 일으키기도 한다. 유물 목록은 유물 목록 참고

마을사람
아무능력이 없는 캐릭터
열심히 말을 하면 되는 캐릭터라 늑대인간이 마을사람이라고 속이는 경우도 있다. 기본적으로 아무 능력이 없는 캐릭터기 때문에, 능숙해 지면 제외하고 하는 것이 좋다. 어차피 가운데 세장의 카드가 깔리기 때문에, 늑대인간도 숨을려면 충분히 숨을 수 있다.
테너 (테너)
자신이 죽어야 승리한다.
이 게임의 두번째 트롤러이다. 하지만 자신이 죽어야만 승리하기 때문에, 승률이 그렇게 좋지는 않다. 적당한 어그로를 끌어서 테너라는 의혹을 피하고 늑대라는 의혹을 받아서 투표로 죽어야 하는 캐릭터.
헌터 (헌터)
헌터이 죽을 때, (투표 시) 지목했던 사람과 함께 죽는다.
영웅이 되겠다고 어그로를 끌어서 일부로 죽지만 말자.
*/

const StaticRolls = {
  '테너':{
    turn: false,
    description: '자신이 죽어야 승리한다.'
  },
  '늑대인간':{
    turn: 2.0,
    description: '자신의 차례때 눈을 떠 다른 늑대인간을 확인한다. 만약 자신 혼자 늑대인간 일 경우는 가운데 카드 중 한장을 확인 할 수 있다.',
  },
};

const DynamicRolls = {
  '신비주의자 늑대':{
    turn: 2.3,
    description: '자신의 차례때 눈을 떠 다른 늑대인간을 확인한다. 혼자 일어나서 다른 플레이어 한 명의 직업을 볼 수 있다.'
  },
  '띵':{
    turn: 4.2,
    description: '자신의 오른쪽 혹은 왼쪽에 있는 사람에게 가까운 쪽 어깨를 살짝 건든다.'
  },
  '씨어':{
    turn: 5,
    description: '가운데 놓여진 카드 3장 중 2장을 보거나 다른 사람의 카드 한 장을 볼 수 있다.'
  },
  '로버':{
    turn: 6,
    description: '다른 사람의 카드와 자신의 카드를 바꾼 후 바꾼 카드를 확인할 수 있다.'
  },
  '트러블메이커':{
    turn: 7,
    description: '다른 두 사람의 카드를 서로 바꾼다.'
  },
  '아우라 씨어':{
    turn: 7.3,
    description: '아우라 씨어 차례 이전에 밤에 카드를 움직이거나 확인한 적이 있는 모든 사람을 확인한다.'
  },
  '인썸니아':{
    turn: 9,
    description: '자신의 차례때 자신의 카드를 다시 확인한다.'
  },
  //'스콰이어':{
  //  turn: 9.3,
  //  description: '모든 늑대는 엄지 손가락을 올리고, 스콰이어는 그들을 확인한다. 이와 함께 그들의 직업 카드를 확인하여 직업 변동 여부 역시 확인한다.'
  //},
  '비홀더':{
    turn: 9.9,
    description: '씨어와 견습 씨어는 엄지 손가락을 올리고, 비홀더는 그들을 확인한다. 이와 함께 씨어와 견습 씨어의 직업 카드를 확인하여 직업 변동 여부 역시 확인한다.'
  },
  //'패밀리맨':{
  //  turn: 13.2,
  //  description: '패밀리맨은 가족을 랜덤으로 1~2명이 지정됩니다. 자신과 가족을 지켜야만 승리합니다.'
  //},
  '헌터':{
    turn: false,
    description: '헌터는 죽을 때, (투표 시) 지목했던 사람과 함께 죽는다.'
  },
  '프린스':{
    turn: false,
    description: '프린스는 투표로 죽지 않는다. 투표에서 1위를 차지한 플레이어가 왕자라면 2위인 플레이어가 죽는다.'
  },
  '빌리저':{
    turn: false,
    description: '청렴결백한 모범시민입니다.'
  },
  '미니언':{
    turn: false,
    description: '자신의 차례때 늑대인간이 누군지 확인 할 수 있다. 늑대인간은 엄지 손가락을 들어 확인시킨다. (단 늑대인간은 미니언을 모른다.)'
  }
};

var util_common = require("../util_common");

const gameManager = {};
var gameRooms = {};

function GameData(step, turn, rolls, wolfRolls, players, allPlayers, wolfPlayers, noWolfPlayers, seerPlayers, midCards, werewolf, mysticWerewolf, minion, thing, seer, robber, troublemaker, auraseer, drunken, insomniac, squire, beholder, tanner, familyman) {
  this.step = step,
  this.turn = turn,
  this.rolls = rolls,
  this.wolfRolls = wolfRolls;
  this.players = players,
  this.allPlayers = allPlayers,
  this.wolfPlayers = wolfPlayers,
  this.noWolfPlayers = noWolfPlayers;
  this.seerPlayers = seerPlayers,
  this.nightActivePlayers = [],
  this.midCards = midCards,
  this.werewolf = werewolf,
  this.mysticWerewolf = mysticWerewolf,
  this.minion = minion,
  this.thing = thing,
  this.seer = seer,
  this.robber = robber,
  this.troublemaker = troublemaker,
  this.auraseer = auraseer,
  this.drunken = drunken,
  this.insomniac = insomniac,
  this.squire = squire,
  this.beholder = beholder,
  this.tanner = tanner,
  this.familyman = familyman
}

function PlayerData(roll, turn, description, point) {
  this.roll = roll,
  this.lastRoll = roll,
  this.turn = turn,
  this.description = description,
  this.point = point,
  this.vote = false
}

function shuffleRoll(playersN) {
  var leftn = playersN - 2 + 3; //4:StaticRolls.length
  var dynamicArray = Object.keys(DynamicRolls);
  var randomi = util_common.shuffleArray(Array.from(Array(dynamicArray.length).keys())).slice(0,leftn);
  randomi.sort();
  var rolls = Object.assign({}, StaticRolls);
  for (var i = 0; i < leftn; i++) {
    var j = randomi[i];
    rolls[dynamicArray[j]] = DynamicRolls[dynamicArray[j]];
  }
  return rolls;
}

function gameSetInit(roomId, users) {
  var step = 'start';
  var turn = false;
  var players = {};
  var wolfRolls = ['늑대인간','신비주의자 늑대'];
  var seerRolls = ['씨어'];
  var allPlayers = [];
  var wolfPlayers = [];
  var noWolfPlayers = [];
  var seerPlayers = [];
  var werewolf, mysticWerewolf, minion, thing, seer, robber, troublemaker, auraseer, drunken, insomniac, squire, beholder, tanner, familyman;
  var Rolls = shuffleRoll(users.length);
  var rolls = Object.keys(Rolls);
  var midCards = [];
  var randomUsers = util_common.shuffleArray(users);
  var randomRolls = util_common.shuffleArray(rolls);
  for (var i=0; i < randomUsers.length; i++) {
    var j = randomRolls[i];
    var playerName = randomUsers[i];
    players[playerName] = new PlayerData(j, Rolls[j].turn, Rolls[j].description);
    allPlayers.push(playerName);
    if (wolfRolls.indexOf(j) > -1) {
      wolfPlayers.push(playerName);
    } else {
      noWolfPlayers.push(playerName);
    }
    if (seerRolls.indexOf(j) > -1) {
      seerPlayers.push(playerName);
    }
    if (j === '늑대인간') {
      werewolf = playerName;
    } else if (j === '신비주의자 늑대') {
      mysticWerewolf = playerName;
    } else if (j === '미니언') {
      minion = playerName;
    } else if (j === '띵') {
      thing = playerName;
    } else if (j === '씨어') {
      seer = playerName;
    } else if (j === '로버') {
      robber = playerName;
    } else if (j === '트러블메이커') {
      troublemaker = playerName;
    } else if (j === '아우라 씨어') {
      auraseer = playerName;
    } else if (j === '드렁큰') {
      drunken = playerName;
    } else if (j === '인썸니아') {
      insomniac = playerName;
    } else if (j === '스콰이어') {
      squire = playerName;
    } else if (j === '비홀더') {
      beholder = playerName;
    } else if (j === '테너') {
      tanner = playerName;
    } else if (j === '패밀리맨') {
      familyman = playerName;
    }
  }
  for (i=1; i < 4; i++) {
    j = randomRolls[randomRolls.length-i];
    midCards.push(j);
  }
  gameRooms[roomId] = new GameData(step, turn, rolls, wolfRolls, players, allPlayers, wolfPlayers, noWolfPlayers, seerPlayers, midCards, werewolf, mysticWerewolf, minion, thing, seer, robber, troublemaker, auraseer, drunken, insomniac, squire, beholder, tanner, familyman);
}

gameManager.start = function(roomId, users) {
  gameSetInit(roomId, users);
};

gameManager.info = function(roomId) {
  return gameRooms[roomId];
};

gameManager.end = function(roomId) {
  gameRooms[roomId] = undefined;
  delete gameRooms[roomId];
  console.log('end', roomId);
};

module.exports = gameManager;
