var express  = require("express");
var router   = express.Router();
var util     = require("../util");


// Home
router.get("/", util.isLoggedin, function(req, res){
  res.render("king/show", {
    username:req.user.username
  });
});

// Dev
router.get("/dev/:id", function(req, res){
  res.render("king/show", {
    username: req.params.id
  });
});

module.exports = router;
