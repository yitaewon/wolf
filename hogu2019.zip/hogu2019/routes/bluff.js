var express  = require("express");
var router   = express.Router();
var util     = require("../util");

// Home
router.get("/", util.isLoggedin, function(req, res){
  res.render("bluff/index", {
    username:req.user.username
  });
});

router.get("/new", util.isLoggedin, function(req, res){
  res.render("bluff/new", {
    username:req.user.username
  });
});

// show
router.get("/:roomId", util.isLoggedin, function(req, res){
  res.render("bluff/show", {
    username:req.user.username,
    roomId:req.params.roomId
  });
});

router.get("/dev/:roomId/:devname", function(req, res){
  res.render("bluff/show", {
    username:req.params.devname,
    roomId:req.params.roomId
  });
});

module.exports = router;
