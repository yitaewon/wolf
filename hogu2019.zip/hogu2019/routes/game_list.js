var express  = require("express");
var router   = express.Router();
var util     = require("../util");

// Home
router.get("/", function(req, res){
  res.render("game_list/", {
  });
});

module.exports = router;
