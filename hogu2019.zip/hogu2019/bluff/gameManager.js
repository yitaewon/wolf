const gameManager = {};
var gameRooms = {};

function PlayerData(isTurn, isOver, diceN, dices, rank) {
  this.isTurn = isTurn,
  this.isOver = isOver,
  this.diceN = diceN,
  this.dices = dices,
  this.rank = rank
}

function GameData(step, players, playerN, leftPlayers, curDice, curDiceN, curTurn, playerDatas) {
  this.step = step,
  this.players = players,
  this.playerN = playerN,
  this.leftPlayers = leftPlayers,
  this.curDice = curDice,
  this.curDiceN = curDiceN,
  this.curTurn = curTurn,
  this.playerDatas = playerDatas
}

function rollDiceInit(players) {
  var playerDatas = {};
  var playerN = players.length;
  var isTurn = true;
  var isOver = false;
  var diceN = Math.max(6, Math.min(6, parseInt(30/playerN)));
  var dices = [];
  var rank = '';
  for (var i = 0; i < playerN; i++) {
    dices = gameManager.roll(diceN);
    playerDatas[players[i]] = new PlayerData(isTurn, isOver, diceN, dices, rank);
    isTurn = false;
  }
  return playerDatas;
}

gameManager.roll = function(diceN) {
  var dices = [];
  var r = 0;
  for (var i = 0; i < diceN; i++) {
    r = Math.floor(6*Math.random())+1;
    if (r === 6) {
      dices.push('★');
    } else {
      dices.push(r);
    }
  }
  dices.sort();
  return dices;
}

gameManager.start = function(roomId, users) {
  var step = "ready";
  shuffleArray(users);
  var players = users;
  var playerN = players.length;
  var leftPlayers = players.slice();
  var curDice = '★';
  var curDiceN = '0';
  var curTurn = players[0];
  var playerDatas = rollDiceInit(players);
  gameRooms[roomId] = new GameData(step, players, playerN, leftPlayers, curDice, curDiceN, curTurn, playerDatas);
}

gameManager.info = function(roomId) {
  return gameRooms[roomId];
}

gameManager.end = function(roomId) {
  gameRooms[roomId] = undefined;
  delete gameRooms[roomId];
  console.log('bluff end', roomId);
}

gameManager.isValid = function(curDice, curDiceN, dice, diceN) {
  if (parseInt(diceN) < 1) {
    return false;
  }
  if (curDice === '★') {
    if (dice === '★') {
      if (parseInt(curDiceN) < parseInt(diceN)) return true;
    } else {
      if (parseInt(curDiceN)*2 <= parseInt(diceN))  return true;
    }
  } else {
    if (dice === '★') {
      if (parseInt(curDiceN)/2 < parseInt(diceN)) return true;
    } else {
      if (parseInt(curDiceN) < parseInt(diceN)) {
        return true;
      } else if (parseInt(curDiceN) === parseInt(diceN)) {
        if (parseInt(curDice) < parseInt(dice)) return true;
      }
    }
  }
  return false;
}

gameManager.totalCount = function(roomId) {
  var curDice = gameRooms[roomId].curDice;
  var curDiceN = gameRooms[roomId].curDiceN;
  var count = 0;
  for (var i in gameRooms[roomId].playerDatas) {
    for (var j = 0; j < gameRooms[roomId].playerDatas[i].dices.length; j++) {
      if (gameRooms[roomId].playerDatas[i].dices[j] === '★') {
        count++;
      } else if (gameRooms[roomId].playerDatas[i].dices[j] === parseInt(curDice)) {
        count++;
      }
    }
  }
  return count;
}

gameManager.draw = function(roomId, bluffPlayer, diffDiceN) {
  var idx = gameRooms[roomId].leftPlayers.indexOf(bluffPlayer);
  var preIdx = (gameRooms[roomId].leftPlayers.length+idx-1) % gameRooms[roomId].leftPlayers.length;
  var prePlayer = gameRooms[roomId].leftPlayers[preIdx];

  for (var i in gameRooms[roomId].playerDatas) {
    if (i === prePlayer)  continue;
    gameRooms[roomId].playerDatas[i].diceN = Math.max(0, gameRooms[roomId].playerDatas[i].diceN - 1)
  }
}

gameManager.win = function(roomId, bluffPlayer, diffDiceN) {
  var idx = gameRooms[roomId].leftPlayers.indexOf(bluffPlayer);
  var preIdx = (gameRooms[roomId].leftPlayers.length+idx-1) % gameRooms[roomId].leftPlayers.length;
  var prePlayer = gameRooms[roomId].leftPlayers[preIdx];
  gameRooms[roomId].playerDatas[prePlayer].diceN = Math.max(0, gameRooms[roomId].playerDatas[prePlayer].diceN - diffDiceN)
}

gameManager.lose = function(roomId, bluffPlayer, diffDiceN) {
  var diceN = Math.max(0, gameRooms[roomId].playerDatas[bluffPlayer].diceN - diffDiceN);
  gameRooms[roomId].playerDatas[bluffPlayer].diceN = diceN;
  if (diceN === 0) {
    gameRooms[roomId].playerDatas[bluffPlayer].isTurn = false;

    var idx = gameRooms[roomId].leftPlayers.indexOf(bluffPlayer);
    var nextIdx = ++idx % gameRooms[roomId].leftPlayers.length;
    gameRooms[roomId].curTurn = gameRooms[roomId].leftPlayers[nextIdx];
    gameRooms[roomId].playerDatas[gameRooms[roomId].curTurn].isTurn = true;
  }
}

module.exports = gameManager;


function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}
