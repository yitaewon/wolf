
// Chat Page
function chatShow() {
  var msg = document.getElementById("chatMsg");
  msg.style.height = "50%";
  $("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);

  var btn = document.getElementById("chatShowBtn")
  btn.value = '&#9660;'
  btn.innerHTML = '&#9660;'
  btn.onclick = chatHide;
}

function chatHide() {
  var msg = document.getElementById("chatMsg");
  msg.style.height = "25px";
  $("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);

  var btn = document.getElementById("chatShowBtn")
  btn.value = '&#9650;'
  btn.innerHTML = '&#9650;'
  btn.onclick = chatShow;
}

function countUpDice(pid) {
  var txtInvoer = document.getElementById(pid);
  var i = txtInvoer.value;
  if (i === '★') {
    txtInvoer.value = 1;
  } else if (i === '5') {
    txtInvoer.value = '★'
  } else {
    txtInvoer.value = parseInt(i, 10) % 6 + 1;
  }
}

function countDownDice(pid) {
  var txtInvoer = document.getElementById(pid);
  var i = txtInvoer.value;
  if (i === '★') {
    txtInvoer.value = 5;
  } else if (i === '1') {
    txtInvoer.value = '★'
  } else {
    txtInvoer.value = parseInt(i, 10) % 6 - 1;
  }
}

function countUp(pid) {
  var txtInvoer = document.getElementById(pid);
  var i = parseInt(txtInvoer.value, 10);
  if (i < 30) {
    txtInvoer.value = ++i;
  }
}

function countDown(pid) {
  var txtInvoer = document.getElementById(pid);
  var i = parseInt(txtInvoer.value, 10);
  if (i > 1) {
    txtInvoer.value = --i;
  }
}

document.getElementById("userDiceBtnUp").addEventListener("click", function() {
    countUpDice("userDice");
}, false);
document.getElementById("userDiceBtnDown").addEventListener("click", function() {
    countDownDice("userDice");
}, false);
document.getElementById("userDiceNBtnUp").addEventListener("click", function() {
    countUp("userDiceN");
}, false);
document.getElementById("userDiceNBtnDown").addEventListener("click", function() {
    countDown("userDiceN");
}, false);

function enableBtnRoll() {
  document.getElementById("userDiceBtnUp").disabled = false;
  document.getElementById("userDiceBtnDown").disabled = false;
  document.getElementById("userDiceNBtnUp").disabled = false;
  document.getElementById("userDiceNBtnDown").disabled = false;
  document.getElementById("btnRoll").disabled = false;
  document.getElementById("btnBluff").disabled = false;
}
function disableBtnRoll() {
  document.getElementById("userDiceBtnUp").disabled = true;
  document.getElementById("userDiceBtnDown").disabled = true;
  document.getElementById("userDiceNBtnUp").disabled = true;
  document.getElementById("userDiceNBtnDown").disabled = true;
  document.getElementById("btnRoll").disabled = true;
  document.getElementById("btnBluff").disabled = true;
}

function createTable(turnInfo, players) {
	var myTableDiv = document.getElementById("gameBoard");
	// tbody
	var tableBody = document.createElement('TBODY');
  var tr, td, i;

  for (var t in turnInfo) {
    var i = turnInfo[t];
    tr = document.createElement('TR');
    tr.id = i;
    tableBody.appendChild(tr);

    if (players[i].turn === true) {
      tr.style.backgroundColor = '#DBF2EC';
    }

    td = document.createElement('TD');
    td.id = "dice";
    td.appendChild(document.createTextNode(players[i].rank));
    tr.appendChild(td);

    td = document.createElement('TD');
    td.style.color = getColor(i);
    td.appendChild(document.createTextNode(i));
    tr.appendChild(td);

    for (var d in players[i].dices) {
      td = document.createElement('TD');
      td.id = "dice";
      td.style.color = getColor(i);
      td.appendChild(document.createTextNode(players[i].dices[d]));
      tr.appendChild(td);
    }
  }
	myTableDiv.appendChild(tableBody);
}

function deleteTable() {
  $("#gameBoard tr").remove();
}

function changeTurnTable(player) {
  var tr = document.getElementById("gameBoard").getElementsByTagName("tr");
  for(var i=0;i<tr.length;i++){
    if (player === tr[i].id) {
      tr[i].style.backgroundColor = '#DBF2EC';
    } else {
      tr[i].style.backgroundColor = 'transparent';
    }
  }
}
