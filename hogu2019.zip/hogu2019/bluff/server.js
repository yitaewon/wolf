var gm = require("./gameManager");
var rooms = {};

// define constructor function that gets `io` send to it
module.exports = function(io) {
  const bluffio = io.of('/bluff');
  bluffio.on('connection', function(socket){

    socket.on('join room',function(roomId, username){
      socket.username = username;
      socket.room_id = roomId;
      socket.join(roomId); //룸입장

      if (rooms.roomId === undefined) {
        rooms.roomId = {};
      }
      rooms.roomId[socket.username] = socket.id;

      console.log(socket.id, socket.username, 'connect');
      bluffio.to(socket.room_id).emit('join room', {
        username: socket.username
      });

      // rejoin refresh game data
      var gmInfo = gm.info(socket.room_id);
      if (gmInfo === undefined)  return;

      bluffio.to(socket.id).emit('game dice', {
        curDice: gmInfo.curDice,
        curDiceN: gmInfo.curDiceN
      });
      var playersInfo = {};
      var diceTotal = 0;
      for (var j in gmInfo.playerDatas) {
        playersInfo[j] = {};
        playersInfo[j].turn = gmInfo.playerDatas[j].isTurn;
        playersInfo[j].rank = gmInfo.playerDatas[j].rank;
        if (socket.username === j) {
          playersInfo[j].dices = gmInfo.playerDatas[j].dices;
        } else {
          playersInfo[j].dices = Array(gmInfo.playerDatas[j].diceN).fill('?');
        }
        diceTotal += gmInfo.playerDatas[j].diceN;
      }
      bluffio.to(socket.id).emit('create table', {
        turnInfo: gmInfo.players,
        playersInfo: playersInfo
      });
      // display total dice numbers
      bluffio.to(socket.id).emit('game dice total', diceTotal);
      // disable enable turn
      if (gmInfo.curTurn === socket.username) {
        bluffio.to(socket.id).emit('enable turn');
      } else {
        bluffio.to(socket.id).emit('disable turn');
      }
    });
    socket.on('disconnect',function(){
      console.log(socket.id, socket.username, 'disconnected');
    });

    socket.on('leave room', function(){
      var roomId = socket.room_id;
      if (rooms.roomId === undefined) {
        return;
      }
      if (rooms.roomId[socket.username] !== undefined) {
        rooms.roomId[socket.username] = undefined;
        delete rooms.roomId[socket.username];
      }
      bluffio.to(socket.room_id).emit('leave room', {
        username: socket.username
      });
      socket.leave(socket.room_id);//룸퇴장
    });

    socket.on('chat message', function(msg){
      //socket.broadcast.to(room_id).emit('msgAlert',data); //자신 제외 룸안의 유저
      //socket.in(room_id).emit('msgAlert',data); //broadcast 동일하게 가능 자신 제외 룸안의 유저
      //io.of('namespace').in(room_id).emit('msgAlert', data) //of 지정된 name space의 유저의 룸
      bluffio.to(socket.room_id).emit('chat message', {
        username: socket.username,
        message: msg
      });
    });

    socket.on('game start', function() {
      var roomId = socket.room_id;
      var players = Object.keys(rooms.roomId);
      gm.start(socket.room_id, players);
      var gmInfo = gm.info(socket.room_id);
      if (gmInfo === undefined) return;

      bluffio.to(socket.room_id).emit('game dice', {
        curDice: gmInfo.curDice,
        curDiceN: gmInfo.curDiceN
      });

      var playersInfo = {};
      var diceTotal = 0
      for (var i in gmInfo.playerDatas) {
        for (var j in gmInfo.playerDatas) {
          playersInfo[j] = {};
          playersInfo[j].turn = gmInfo.playerDatas[j].isTurn;
          playersInfo[j].rank = gmInfo.playerDatas[j].rank;
          if (i === j) {
            playersInfo[j].dices = gmInfo.playerDatas[j].dices;
          } else {
            playersInfo[j].dices = Array(gmInfo.playerDatas[j].diceN).fill('?');
          }
        }
        bluffio.to(rooms.roomId[i]).emit('create table', {
          turnInfo: gmInfo.players,
          playersInfo: playersInfo
        });
        diceTotal += gmInfo.playerDatas[i].diceN;
      }
      // display total dice numbers
      bluffio.to(socket.room_id).emit('game dice total', diceTotal);
      // disable enable turn
      bluffio.to(socket.room_id).emit('disable turn');
      bluffio.to(rooms.roomId[gmInfo.curTurn]).emit('enable turn');
    });

    socket.on('game continue', function() {
      var gmInfo = gm.info(socket.room_id);
      if (gmInfo === undefined) return;
      // check game over player
      for (var i = 0; i < gmInfo.leftPlayers.length; i++) {
        var playerName = gmInfo.leftPlayers[i];
        if (gmInfo.playerDatas[playerName].diceN === 0) {
          gmInfo.playerDatas[playerName].isOver = true;
          gmInfo.playerDatas[playerName].rank = gmInfo.leftPlayers.length;
          gmInfo.playerDatas[playerName].dices = [];
        } else {
          gmInfo.playerDatas[playerName].dices = gm.roll(gmInfo.playerDatas[playerName].diceN);
        }
      }
      // delete game over players
      for (var i = 0; i < gmInfo.leftPlayers.length; i++) {
        var playerName = gmInfo.leftPlayers[i];
        if (gmInfo.playerDatas[playerName].diceN === 0) {
          for (var j = 0; j < gmInfo.leftPlayers.length; j++){
            if (gmInfo.leftPlayers[j] === playerName) {
              gmInfo.leftPlayers.splice(j, 1);
            }
          }
        }
      }

      // init current dices
      gmInfo.curDice = '★';
      gmInfo.curDiceN = 0;

      bluffio.to(socket.room_id).emit('game dice', {
        curDice: gmInfo.curDice,
        curDiceN: gmInfo.curDiceN
      });

      var playersInfo = {};
      var diceTotal = 0
      for (var i in gmInfo.playerDatas) {
        for (var j in gmInfo.playerDatas) {
          playersInfo[j] = {};
          playersInfo[j].turn = gmInfo.playerDatas[j].isTurn;
          playersInfo[j].rank = gmInfo.playerDatas[j].rank;
          if (i === j) {
            playersInfo[j].dices = gmInfo.playerDatas[j].dices;
          } else {
            playersInfo[j].dices = Array(gmInfo.playerDatas[j].diceN).fill('?');
          }
        }
        bluffio.to(rooms.roomId[i]).emit('create table', {
          turnInfo: gmInfo.players,
          playersInfo: playersInfo
        });
        diceTotal += gmInfo.playerDatas[i].diceN;
      }
      // display total dice numbers
      bluffio.to(socket.room_id).emit('game dice total', diceTotal);
      // disable enable turn
      bluffio.to(socket.room_id).emit('disable turn');
      bluffio.to(rooms.roomId[gmInfo.curTurn]).emit('enable turn');
    });

    socket.on('user roll', function(data) {
      var roomId = socket.room_id;
      var gmInfo = gm.info(socket.room_id);
      if (gmInfo === undefined) return;
      // valid turn
      if (gmInfo.curTurn !== socket.username) {
        bluffio.to(rooms.roomId[socket.username]).emit('disable turn');
        return;
      }
      // valid dice
      if (gm.isValid(gmInfo.curDice, gmInfo.curDiceN, data.dice, data.diceN) === false ) {
        return;
      }
      // disable turn
      bluffio.to(rooms.roomId[socket.username]).emit('disable turn');

      gmInfo.curDice = data.dice;
      gmInfo.curDiceN = data.diceN;
      bluffio.to(socket.room_id).emit('game dice', {
        curDice: gmInfo.curDice,
        curDiceN: gmInfo.curDiceN
      });

      var idx = gmInfo.leftPlayers.indexOf(gmInfo.curTurn);
      var nextIdx = ++idx % gmInfo.leftPlayers.length;
      gmInfo.playerDatas[gmInfo.curTurn].isTurn = false;
      gmInfo.curTurn = gmInfo.leftPlayers[nextIdx];
      gmInfo.playerDatas[gmInfo.curTurn].isTurn = true;
      // change turn table
      bluffio.to(socket.room_id).emit('change turn table', gmInfo.curTurn);
      // enable turn
      bluffio.to(rooms.roomId[gmInfo.curTurn]).emit('enable turn');
    });

    socket.on('user bluff', function() {
      var roomId = socket.room_id;
      var gmInfo = gm.info(socket.room_id);
      if (gmInfo === undefined) return;
      // valid turn
      if (gmInfo.curTurn !== socket.username) {
        bluffio.to(rooms.roomId[socket.username]).emit('disable turn');
        return;
      }
      if (parseInt(gmInfo.curDiceN) === 0) {
        return;
      }
      // disable enable turn
      bluffio.to(socket.room_id).emit('disable turn');
      // chat bluff
      bluffio.to(socket.room_id).emit('chat message bluff', {
        username: socket.username
      });
      // show all players dice
      var playersInfo = {};
      for (var j in gmInfo.playerDatas) {
        playersInfo[j] = {};
        playersInfo[j].turn = gmInfo.playerDatas[j].isTurn;
        playersInfo[j].rank = gmInfo.playerDatas[j].rank;
        playersInfo[j].dices = gmInfo.playerDatas[j].dices;
      }
      bluffio.to(socket.room_id).emit('create table', {
        turnInfo: gmInfo.players,
        playersInfo: playersInfo
      });
      // count total dice numbers
      var totalDiceN = gm.totalCount(socket.room_id);
      var msg = ('Total:').concat(gmInfo.curDice).concat('x').concat(totalDiceN);
      var diffDiceN = parseInt(totalDiceN) - parseInt(gmInfo.curDiceN);
      var bluffPlayer = socket.username;
      if (diffDiceN === 0) {
        msg = msg.concat(' == ')
        gm.draw(socket.room_id, bluffPlayer, Math.abs(diffDiceN));
      } else if (diffDiceN > 0) {
        msg = msg.concat(' > ')
        gm.lose(socket.room_id, bluffPlayer, Math.abs(diffDiceN));
      } else if (diffDiceN < 0) {
        msg = msg.concat(' < ')
        gm.win(socket.room_id, bluffPlayer, Math.abs(diffDiceN));
      }
      msg = msg.concat(gmInfo.curDice).concat('x').concat(gmInfo.curDiceN);
      bluffio.to(socket.room_id).emit('game message', {
        message: msg
      });

      //setTimeout(function() {
      //  bluffio.to(socket.room_id).emit('game next');
      //}, 4000); // next round after 5seconds
    }); // bluff vutton

    socket.on('game end', function() {
      gm.end(socket.room_id);
      var gmInfo = gm.info(socket.room_id);
      console.log(gmInfo);
    });

  }); // io connection
};
