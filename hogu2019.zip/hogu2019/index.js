var express        = require("express");
var mongoose       = require("mongoose");
var bodyParser     = require("body-parser");
var methodOverride = require("method-override");
var flash          = require("connect-flash");
var session        = require("express-session");
var passport       = require("./config/passport");
var app = express();
var http = require('http').createServer(app);
//var io = require('socket.io')(http);
var io = require("./gameCard/server").listen(http);  // Start Socket.io server and let server handle those connections
// load consumer.js and pass it the socket.io object
require('./bluff/server')(io);
require('./wolf/server')(io);

// DB setting
mongoose.set('useNewUrlParser', true);
mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);
mongoose.connect(process.env.MONGO_DB,{ useNewUrlParser: true });
var db = mongoose.connection;
db.once("open", function(){
  console.log("DB connected");
});
db.on("error", function(err){
  console.log("DB ERROR : ", err);
});

// Other settings
app.set("view engine", "ejs");
app.use(express.static(__dirname));
app.use(express.static(__dirname+"/public"));
app.use(express.static(__dirname+"/gameCard"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(methodOverride("_method"));
app.use(flash());
app.use(session({secret:"MySecret", resave:true, saveUninitialized:true}));

// Passport
app.use(passport.initialize());
app.use(passport.session());

// Custom Middlewares
app.use(function(req,res,next){
  res.locals.isAuthenticated = req.isAuthenticated();
  res.locals.currentUser = req.user;
  next();
});

// Routes
app.use("/", require("./routes/home"));
app.use("/posts", require("./routes/posts"));
app.use("/users", require("./routes/users"));
app.use("/king", require("./routes/king")); //대부호
app.use("/bluff", require("./routes/bluff")); //블러프
app.use("/wolf", require("./routes/wolf")); //한밤의늑대
app.use("/game_list", require("./routes/game_list"));

// Port setting
var port = process.env.PORT || 3000;
http.listen(port, function(){
  console.log("Server On! http://localhost:"+port);
});

module.exports = http;
