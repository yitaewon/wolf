var express = require('express');
var session = require('express-session');
var app = express();
var path = require('path');  // path 모듈 추가
var port = process.env.PORT || 8091;
var bodyParser = require('body-parser');
var methodOverride = require('method-override');
var flash = require('connect-flash');
var passport = require('./config/passport'); // DB 없이 패스포트 설정
var util = require('./common/util');
var server = require('http').createServer(app);
var wolfServer = require('./wolf/server');
var io = require('socket.io')(server);
var sharedsession = require("express-socket.io-session");

// 세션 설정
var sessionMiddleware = session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
});

app.use(sessionMiddleware);
io.use(sharedsession(sessionMiddleware, {
  autoSave: true
}));

// body-parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(methodOverride('_method'));

// view engine 설정
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));  // 뷰 폴더 경로 설정

// 닉네임 미들웨어
app.use((req, res, next) => {
  req.getNickname = () => req.session.nickname || '익명';
  req.setNickname = (nickname) => { req.session.nickname = nickname; };
  next();
});

// flash
app.use(flash());

// passport 초기화
//app.use(passport.initialize());

// static 파일 설정
app.use(express.static(path.join(__dirname, 'public')));

// 루트 경로 처리
app.get('/', (req, res) => {
  res.redirect('/lobby');
});

// 로비 라우트
app.get('/lobby', (req, res) => {
  res.render('home/lobby', { nickname: req.session.nickname || '익명' });
});

// 닉네임 설정 라우트
app.post('/set-nickname', (req, res) => {
  req.session.nickname = req.body.nickname;
  res.json({ success: true, nickname: req.session.nickname });
});

// set routes
app.use('/users', require('./routes/users'));
app.use('/rooms', require('./routes/rooms'));
app.use('/roles', require('./routes/roles'));

// Socket.IO 설정
io.on('connection', (socket) => {
  const session = socket.handshake.session;
  if (!session) {
    console.error('세션이 정의되지 않았습니다.');
    return;
  }
  const username = session.nickname || '익명';
  const roomid = socket.handshake.query.roomid;
  
  console.log('새로운 사용자 연결:', username);

  socket.on('set nickname', (nickname) => {
    socket.handshake.session.nickname = nickname;
    socket.handshake.session.save();
    console.log('닉네임 설정:', nickname);
  });

  socket.on('join room', (roomid, username) => {
    socket.join(roomid);
    console.log(`${username}님이 ${roomid} 방에 입장했습니다.`);
    
    // 방에 입장한 사용자 정보를 모든 클라이언트에게 브로드캐스트
    io.to(roomid).emit('user joined', { username, roomid });
  });

  socket.on('chat message', (data) => {
    console.log('채팅 메시지 수신:', data);
    io.to(data.roomid).emit('chat message', {
      username: data.username || username,  // 닉네임이 없으면 소켓 연결 시의 닉네임 사용
      message: data.message
    });
  });

  // 기존 wolfServer 로직과 통합
  wolfServer(io, socket);
});

// 서버 시작
server.listen(port, '0.0.0.0', function(err){
  if (err) {
    console.error('서버 시작 오류:', err);
  } else {
    console.log('서버가 ' + port + '번 포트에서 실행중입니다.');
    console.log('http://localhost:' + port + '로 접속해보세요.');
  }
});
