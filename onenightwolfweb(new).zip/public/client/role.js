(function() {
  // 전역 socket 객체를 사용합니다.
  // 이 객체는 show.ejs에서 생성되어야 합니다.

  // 전역 함수로 노출할 함수들을 저장할 객체
  const publicFunctions = {};

  // join room
  publicFunctions.saveRoles = function(roomid, roleIds) {
    if (typeof socket !== 'undefined') {
      socket.emit('save roles', roomid, roleIds);
    } else {
      console.error('Socket is not defined');
    }
  };

  // show user list on rooms
  if (typeof socket !== 'undefined') {
    socket.on('show users', function(users, master){
      var tr, td, div;
      $('#userRoom').empty();
      for (let user of users) {
        tr = document.createElement("tr");

        td = document.createElement("td");
        div = document.createElement("div");
        td.className = "level";
        div.className = "ellipsis";
        div.innerHTML = user.player.level;
        td.appendChild(div);
        tr.appendChild(td);

        td = document.createElement("td");
        div = document.createElement("div");
        td.className = "rating";
        div.className = "ellipsis";
        div.innerHTML = user.player.rating;
        td.appendChild(div);
        tr.appendChild(td);

        td = document.createElement("td");
        div = document.createElement("div");
        td.className = "player";
        div.className = "ellipsis";
        if (user.player._id === master._id) {
          div.innerHTML = "ⓜ ".concat(user.player.username);
        } else {
          div.innerHTML = user.player.username;
        }
        td.appendChild(div);
        tr.appendChild(td);

        td = document.createElement("td");
        div = document.createElement("div");
        td.className = "ready";
        div.className = "ellipsis";
        if (user.player.isReady === true) {
          div.innerHTML = "준비완료";
        } else {
          div.innerHTML = "준비";
        }
        td.appendChild(div);
        tr.appendChild(td);

        document.getElementById("userRoom").appendChild(tr);
      }
    });
  }

  // show roles on room
  publicFunctions.showRoleRoom = function(roleSrcs) {
    if (typeof socket !== 'undefined') {
      socket.emit('show roles', roleSrcs);
    } else {
      console.error('Socket is not defined');
    }
  };

  if (typeof socket !== 'undefined') {
    socket.on('show roles', function(roleSrcs){
      var elem;
      for (let role of roleSrcs) {
        elem = document.createElement("img");
        elem.className = "imgRoleRoom";
        elem.src = role.image;
        document.getElementById("roleRoom").appendChild(elem);
      }
      $('#roleRoomNum').text(Object.keys(roleSrcs).length);
    });
  }

  // start game
  publicFunctions.startGame = function(roomid) {
    if (typeof socket !== 'undefined') {
      socket.emit('start game', roomid);
    } else {
      console.error('Socket is not defined');
    }
  };

  if (typeof socket !== 'undefined') {
    socket.on('start game', function(roomid){
      location.href='/rooms/'.concat(roomid).concat('/night');
    });
  }

  // 역할 선택 및 설정 함수
  window.setRoleRoom = function() {
    const selectedRoles = [];
    document.querySelectorAll('#roleSelection .imgRole.selected').forEach(img => {
      selectedRoles.push(img.getAttribute('data-role-id'));
    });
    publicFunctions.saveRoles(roomid, selectedRoles);
    updateRoleRoom(selectedRoles);
  };

  // 선택된 역할을 대기실에 표시하는 함수
  function updateRoleRoom(selectedRoles) {
    const roleRoom = document.getElementById('roleRoom');
    roleRoom.innerHTML = ''; // 기존 내용 초기화

    fetch('/roles/api')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(roles => {
        selectedRoles.forEach(roleId => {
          const role = roles.find(r => r.turn === roleId);
          if (role) {
            const card = document.createElement('div');
            card.className = 'col-md-2';
            card.innerHTML = `
              <img src="${role.image}" class="imgRoleRoom" alt="${role.name}">
              <p>${role.name}</p>
            `;
            roleRoom.appendChild(card);
          }
        });

        document.getElementById('roleRoomNum').textContent = selectedRoles.length;
      })
      .catch(error => console.error('Error fetching roles:', error));
  }

  // 전역 범위에 함수들을 노출
  window.saveRoles = publicFunctions.saveRoles;
  window.showRoleRoom = publicFunctions.showRoleRoom;
  window.startGame = publicFunctions.startGame;

  // 역할 데이터를 가져와 모달 창에 표시하는 함수
  function showRoleSelectionModal() {
    fetchRoles(roles => {
      const modalBody = document.getElementById('roleSelection');
      modalBody.innerHTML = ''; // 기존 내용 초기화

      roles.forEach(role => {
        const card = document.createElement('div');
        card.className = 'col-md-2';
        card.innerHTML = `
          <img src="${role.image}" class="imgRole" alt="${role.name}" data-role-id="${role.turn}">
          <p>${role.name}</p>
        `;
        modalBody.appendChild(card);
      });
    });
  }

  // 설정 버튼 클릭 시 모달 창 열기
  const btnSettings = document.getElementById('btn-settings');
  if (btnSettings) {
    btnSettings.addEventListener('click', function() {
      showRoleSelectionModal();
      $('#settingModal').modal('show');
    });
  }

  function fetchRoles(callback) {
    fetch('/roles/api')
      .then(response => response.json())
      .then(data => callback(data))
      .catch(error => console.error('Error fetching roles:', error));
  }
})();
