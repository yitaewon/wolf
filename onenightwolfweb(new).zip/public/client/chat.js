// 즉시 실행 함수를 사용하여 전역 네임스페이스 오염을 방지합니다
(function() {
  // socket 객체가 전역에 있다고 가정합니다
  const socket = io();

  // 채팅 메시지 수신 이벤트 리스너
  socket.on('chat message', function(data) {
    var span = $('<span class="nickname">').text(data.username).append(' : ');
    var li = $('<li>').append(span).append(data.message).css('color', '#FFFFFF');
    $('#chatMsg').append(li);
    $("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);
  });

  // 메시지 전송 함수
  function sendMessage(message) {
    const username = "<%= nickname %>"; // 닉네임을 가져옵니다.
    socket.emit('chat message', { roomid, username, message });
  }

  // 폼 제출 이벤트 리스너
  $('#chatForm').submit(function(e) {
    e.preventDefault();
    const messageInput = $('#chatInput');
    const message = messageInput.val();
    if (message.trim()) {
      sendMessage(message);
      messageInput.val('');
    }
  });

  // 필요한 경우 전역 범위에 함수를 노출합니다
  window.sendChatMessage = sendMessage;
})();
