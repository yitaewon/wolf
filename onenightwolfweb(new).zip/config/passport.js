module.exports = {
  initialize: () => (req, res, next) => next()
};
