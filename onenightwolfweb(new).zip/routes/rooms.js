var express = require("express");
var router  = express.Router();
var { rooms } = require("../wolf/server");
var Role = require("../models/Role"); // Role 데이터를 가져오기

// show
router.get("/:id", function(req, res){
  const room = rooms[req.params.id];
  
  if (!room) {
    return res.status(404).send('방을 찾을 수 없습니다.');
  }
  
  if (!room.roles) {
    room.roles = [];
  }
  
  // roles 데이터를 사용하여 렌더링
  Role.findAll(function(err, roles) {
    if (err) return res.json(err);
    res.render('rooms/show', { room: room, nickname: req.session.nickname, roles: roles });
  });
});

// update
router.post("/:id", function(req, res){
  res.redirect("/rooms/"+req.params.id);
});

// game play turn night
router.get("/:id/night", function(req, res){
  const roomId = req.params.id;
  const room = rooms[roomId];

  if (!room) {
    return res.status(404).send("Room not found");
  }

  res.render("rooms/night", {room: room, user: req.session.nickname});
});

// 방 생성 라우트
router.post("/", function(req, res){
  const roomId = 'room_' + Date.now();
  rooms[roomId] = {
    id: roomId,
    title: req.body.title,
    roles: [] // 역할 초기화
  };
  res.redirect("/rooms/" + roomId);
});

module.exports = router;
