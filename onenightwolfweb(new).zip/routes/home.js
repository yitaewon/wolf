var express = require("express");
var router  = express.Router();

// 모든 라우트에 currentUser와 isAuthenticated를 설정하는 미들웨어
router.use(function(req, res, next) {
  res.locals.currentUser = req.session.nickname || null;
  res.locals.isAuthenticated = !!req.session.nickname;
  next();
});

// Home
router.get("/", function(req, res){
  res.redirect("/lobby");
});

// room list
router.get("/lobby", function(req, res){
  var rooms = [
    { title: "테스트 방 1", master: { username: "사용자1" }, createdAt: new Date() },
    { title: "테스트 방 2", master: { username: "사용자2" }, createdAt: new Date() }
  ];
  res.render("home/lobby", {rooms: rooms, room: {}, errors: {}});
});

// Set nickname
router.post("/set-nickname", function(req, res){
  req.session.nickname = req.body.nickname;
  res.json({ success: true });
});

// room create
router.post("/lobby", function(req, res){
  console.log("새 방 생성 요청:", req.body);
  res.redirect("/lobby");
});

router.get("/about", function(req, res){
  res.render("home/about");
});

// 로그인 페이지
router.get("/login", function(req, res){
  res.render("home/login");
});

// Logout
router.get("/logout", function(req, res) {
  req.session.destroy();
  res.redirect("/lobby");
});

module.exports = router;
