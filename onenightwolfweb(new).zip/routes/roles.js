var express  = require("express");
var router   = express.Router();
var Role     = require("../models/Role");
var { rooms } = require("../wolf/server");

// Index
router.get("/", function(req, res){
  Role.findAll(function(err, roles){
    if(err) return res.json(err);
    res.render("roles/index", {roles:roles});
  });
});

// New
router.get("/new", function(req, res){
  var role = req.flash("role")[0] || {};
  var errors = req.flash("errors")[0] || {};
  res.render("roles/new", { role:role, errors:errors });
});

// create
router.post("/", function(req, res){
  Role.create(req.body, function(err, role){
    if(err){
      req.flash("role", req.body);
      req.flash("errors", { message: "Error creating role" });
      return res.redirect("/roles/new");
    }
    res.redirect("/roles");
  });
});

// show
router.get("/:turn", function(req, res){
  Role.findByTurn(req.params.turn, function(err, role){
    if(err) return res.json(err);
    if(!role) return res.status(404).send("Role not found");
    res.render("roles/show", { role: role, nickname: req.session.nickname, currentUser: req.session.user });
  });
});

// edit
router.get("/:turn/edit", function(req, res) {
  Role.findByTurn(req.params.turn, function(err, role) {
    if (err) return res.json(err);
    res.render('roles/edit', { role: role });
  });
});

// update
router.put("/:turn", function(req, res, next){
  req.body.updatedAt = Date.now();
  Role.updateByTurn(req.params.turn, req.body, function(err, role) {
    if (err) return res.json(err);
    res.redirect('/roles/' + req.params.turn);
  });
});

// 역할 목록 페이지
router.get("/", function(req, res) {
  Role.findAll(function(err, roles){
    if (err) return res.status(500).json({ error: 'Failed to fetch roles' });
    res.json(roles);
  });
});

// 특정 방의 역할 설정 페이지
router.get("/room/:roomId", function(req, res) {
  const roomId = req.params.roomId;
  const room = rooms[roomId];
  if (!room) {
    return res.status(404).send("Room not found");
  }
  Role.findAll(function(err, roles) {
    if (err) return res.json(err);
    res.render("roles/edit", { room: room, allRoles: roles });
  });
});

// 역할 설정 업데이트
router.post("/room/:roomId", function(req, res) {
  const roomId = req.params.roomId;
  const selectedRoles = req.body.roles; // 선택된 역할 turn 배열
  const room = rooms[roomId];
  if (!room) {
    return res.status(404).send("Room not found");
  }
  Role.findAll(function(err, roles) {
    if (err) return res.json(err);
    room.roles = selectedRoles.map(turn => roles.find(role => role.turn === turn));
    res.redirect("/rooms/" + roomId);
  });
});

module.exports = router;
