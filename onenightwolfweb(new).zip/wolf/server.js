var rooms = {};

module.exports = function(io) {
  const bluffio = io.of('/wolf');
  
  function updateRoomList() {
    const roomList = Object.keys(rooms).map(roomId => ({
      id: roomId,
      title: rooms[roomId].title,
      memberCount: rooms[roomId].members.length
    }));
    bluffio.emit('room list update', roomList);
  }

  bluffio.on('connection', function(socket){
    // 연결 시 현재 방 목록 전송
    updateRoomList();

    socket.on('create room', function(roomTitle, callback) {
      const roomId = 'room_' + Date.now();
      rooms[roomId] = { 
        id: roomId,
        title: roomTitle, 
        members: [], 
        messages: [] 
      };
      updateRoomList();
      callback(roomId);
    });

    socket.on('join room', function(roomid, username){
      socket.roomid = roomid;
      socket.username = username;
      socket.join(roomid);

      if (rooms[roomid]) {
        rooms[roomid].members.push({id: socket.id, username: username});
        socket.emit('room info', rooms[roomid]);
        socket.to(roomid).emit('user joined', username);
        updateRoomList();
      }
    });

    socket.on('leave room', function(){
      if (socket.roomid) {
        const room = rooms[socket.roomid];
        if (room) {
          room.members = room.members.filter(member => member.id !== socket.id);
          if (room.members.length === 0) {
            delete rooms[socket.roomid];
          } else {
            socket.to(socket.roomid).emit('user left', socket.username);
          }
        }
        socket.leave(socket.roomid);
      }
    });

    socket.on('chat message', function(msg){
      if (socket.roomid) {
        const message = {username: socket.username, message: msg};
        rooms[socket.roomid].messages.push(message);
        bluffio.to(socket.roomid).emit('chat message', message);
      }
    });

    socket.on('disconnect', function(){
      if (socket.roomid) {
        const room = rooms[socket.roomid];
        if (room) {
          room.members = room.members.filter(member => member.id !== socket.id);
          if (room.members.length === 0) {
            delete rooms[socket.roomid];
          } else {
            socket.to(socket.roomid).emit('user left', socket.username);
          }
          updateRoomList();
        }
      }
    });
  });
}

module.exports.rooms = rooms;
