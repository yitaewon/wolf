module.exports = {}; // 빈 객체로 대체하거나 필요한 로직 추가
