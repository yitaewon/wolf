var util = require("../common/util");

// 역할 데이터 
var roles = [
  {
    name: "Sentinel (수호자)",
    description: "",
    series: "dayBrake",
    team: "villager",
    active: "Y",
    turn: "0",
    image: "/images/wolf_1_villager.jpg"
  },
  {
    name: "DOPPELGANGER (도플갱어)",
    description: "차례가 되면 다른 캐릭터를 보고 그 캐릭터의 능력을 복제한다. 그리고 복제한 캐릭터의 팀에 소속된다.마을주민, 무두장이, 사냥꾼을 복제했을 때는 밤에 아무런 역할을 하지 않는다.예언자, 강도, 말썽쟁이, 주정뱅이를 복제했을 때는 바로 그 능력을 사용한다.늑대인간이나 프리메이슨을 복제했을 때는 그 역할의 차례 때에 같이 눈을 떠 확인한다.하수인을 복제했을 때는 도플갱어의 역할이 끝난 직후 늑대인간이 서로를 확인하기 직전에 엄지 손가락을 들 때 눈을 떠 확인한다. 불면증환자를 복제했을 때는 마지막 불면증환자 다음에 자기 직업을 확인한다.",
    series: "basic",
    team: "neutrality",
    active: "Y",
    turn: "1",
    image: "/images/wolf_1_doppelganger.jpg"
  },
  {
    name: "WEREWOLF (늑대인간)",
    description: "자신의 차례 때 눈을 떠 다른 늑대인간을 확인한다. 만약 자신 혼자 늑대인간일 경우는 가운데 카드 중 한 장을 확인 할 수 있다. 생각보다 어려운 직업으로 승리하기 위해서 상황을 빠르게 파악하고 적절하게 다른 직업을 사칭하며 행동하는 순간대처능력이 중요하다. 오히려 한 명일때가 두 명일때보다 강력한 편이다. 한 명일때는 가운데 카드 정보를 이용해 예언자 행세를 할 수 있지만, 두 명일때는 둘 중 하나만 찍혀도 끝이기 때문에 패배 확률이 2배나 올라간다. 어설프게 걸릴 위기의 때엔 늑대인간이 한명 뿐이라고 하고 다른 늑대인간을 숨겨주면서 교환당했다고 우기는 편이 낫다. 강도나 말썽쟁이에게 교환당한 정황이 포착된 경우, 빠르게 늑밍아웃을 하고 시민 편에 잽싸게 붙어버리는 경우도 있다. 기본적으로 마피아 게임처럼 하면 되지만, 일단 무두장이랑 하수인이 들어가면 내가 늑대인간이야! 라고 진실된 외침을 외쳐도 안 믿는다. 그러니 정 답이 없어 보이면 늑대인간이라고 나서도 된다.",
    series: "basic",
    team: "werewolf",
    active: "Y",
    turn: "2",
    image: "/images/wolf_1_werewolf.jpg"
  },
  {
    name: "ALPHA WOLF (태초의 늑대인간)",
    description: "늑대인간으로 취급한다. 이후에 혼자 일어나서 중앙에 놓여 있는 늑대인간 카드를 늑대인간이 아닌 플레이어와 바꿔서 새로운 늑대인간을 반드시 만든다. 즉 늑대 인간이 늘어나기 때문에, 자칫하면 늑대 인간이 걸릴 확률만 늘려주는 직업. 늑대 인간이 늘어나서 늑대 인간에게 유리한 직업인 듯 하지만, 이로 인해 투표 당하면 지는 대상자들이 많아지고, 더욱이 일부 직업은 태초의 늑대인간이 주려는 가운데 카드를 볼 수도 있어서 불리해지는 느낌이 있다.",
    series: "dayBrake",
    team: "werewolf",
    active: "Y",
    turn: "2B",
    image: "/images/wolf_1_werewolf.jpg"
  },
  {
    name: "MYSTIC WOLF (신비주의 늑대)",
    description: "늑대인간으로 취급한다. 이후에 혼자 일어나서 다른 플레이어 한 명의 직업을 볼 수 있다. 즉 예언자와 늑대인간의 혼합.",
    series: "dayBrake",
    team: "werewolf",
    active: "Y",
    turn: "2C",
    image: "/images/wolf_1_werewolf.jpg"
  },
  {
    name: "MINION (하수인)",
    description: "자신의 차례 때 늑대인간이 누군지 확인할 수 있다. 늑대인간은 엄지 손가락을 들어 확인시킨다. 무두장이와 함께 게임을 빛내는 주역. 하수인이 죽어도 늑대인간은 이기기 때문에 자신이 나서서 대신 죽는 전략도 좋은 방법이다.",
    series: "basic",
    team: "werewolf",
    active: "Y",
    turn: "3",
    image: "/images/wolf_1_minion.jpg"
  },
  {
    name: "MASON (프리메이슨)",
    description: "자신의 차례 때 눈을 떠서 다른 비밀 요원을 확인한다. 이로 인해 비밀 요원 카드는 기본적으로 2장을 한번에 집어넣는다. 혼자 눈을 뜬 경우, 가운데 카드 중 하나가 비밀 요원이라고 생각하면 된다.",
    series: "basic",
    team: "villager",
    active: "Y",
    turn: "4",
    image: "/images/wolf_1_mason.jpg"
  },
  {
    name: "SEER (예언자)",
    description: "가운데 놓여진 카드 3장 중 2장을 보거나, 다른 사람의 카드 한 장을 볼 수 있다. 정보가 가장 많은 직업인 만큼 가장 의심을 많이 받는다. 또 늑대인간도 한 명일 때는 가운데 카드를 뒤집어 볼 수 있기 때문에 예언자라고 주장하기도 한다.",
    series: "basic",
    team: "villager",
    active: "Y",
    turn: "5",
    image: "/images/wolf_1_seer.jpg"
  },
  {
    name: "ROBBER (강도)",
    description: "다른 사람의 카드와 자신의 카드를 바꾼 후 바꾼 카드를 확인할 수 있다. 이때 그 사람의 능력을 쓰진 못 한다. 직업 변경 이후에도 자신의 정체를 안다는 점에서 강점인 캐릭터. 단 말썽쟁이에게 당하면... 강도의 능력이 예언자의 두 번째 능력과 흡사하기 때문에 예언자를 자처할수도 있지만 보통은 트롤링.",
    series: "basic",
    team: "villager",
    active: "Y",
    turn: "6",
    image: "/images/wolf_1_robber.jpg"
  },
  {
    name: "TROUBLEMAKER (말썽쟁이)",
    description: "다른 두 사람의 카드를 서로 바꿀 수 있다. 다만 카드 내용을 확인할 수는 없다. 이 게임의 꽃으로 말썽쟁이가 누구를 바꿨는지 말하자 마자 게임이 종료되는 경우도 많다. 말썽쟁이가 늑대인간이나 하수인을 다른 직업으로 바꿔버렸다는 사실이 알려지면 그들이 배신할 수도 있기 때문. 물론 말썽쟁이가 떠보기 식으로 거짓말을 할 수도 있으므로 주의하여야 한다.",
    series: "basic",
    team: "villager",
    active: "Y",
    turn: "7",
    image: "/images/wolf_1_troublemaker.jpg"
  },
  {
    name: "DRUNK (주정뱅이)",
    description: "가운데 카드 3장 중 하나와 자신의 카드를 반드시 바꾼다. 이때 바꾼 카드를 볼 수 없다. 예언자, 강도, 말썽쟁이의 행동은 선택사항인 반면 주정뱅이의 행동은 반드시 해야 하는 필수행동이다. 자기 직업을 모른다는 특성 때문에 트롤을 하거나 조용히 있거나 둘 중 하나밖에 못하는 캐릭터. 예언자가 가운데 카드 2장을 말해주면 자기 직업을 조금 추측할 수 있다.",
    series: "basic",
    team: "villager",
    active: "Y",
    turn: "8",
    image: "/images/wolf_1_drunk.jpg"
  },
  {
    name: "INSOMNIAC (불면증환자)",
    description: "자신의 차례때 자신의 카드를 다시 확인한다. 어찌보면 시민측 최종보스. 이 게임을 한 사람들의 대다수가 최고의 캐릭터로 꼽을만큼 사기성이 짙다.",
    series: "basic",
    team: "villager",
    active: "Y",
    turn: "9",
    image: "/images/wolf_1_insomniac.jpg"
  }
];

function findAll(callback) {
  callback(null, roles);
}

function findByTurn(turn, callback) {
  const role = roles.find(role => role.turn === turn);
  callback(null, role);
}

module.exports = {
  findAll,
  findByTurn
};
