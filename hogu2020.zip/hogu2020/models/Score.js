var mongoose = require("mongoose");

var scoreSchema = mongoose.Schema({
  index:{
    type:Number,
    trim:true,
  },
  title:{
    type:String,
    required:[true,"title is required!"],
    trim:true,
  },
  user1:{
    type:String,
  },
  user2:{
    type:String,
  },
  user3:{
    type:String,
  },
  user4:{
    type:String,
  },
  user5:{
    type:String,
  },
  user6:{
    type:String,
  },
  user7:{
    type:String,
  },
},{
  toObject:{virtuals:true}
});

var Score = mongoose.model("score",scoreSchema);
module.exports = Score;
