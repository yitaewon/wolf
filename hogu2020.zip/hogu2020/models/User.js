var mongoose = require("mongoose");

var userSchema = mongoose.Schema({
  username:{
    type:String,
    required:[true,"nickname is required!"],
    trim:true,
    unique:true,
  },
  auth_id:{
    type:String,
    required:[true,"auth_id is required!"],
    trim:true,
    unique:true,
  },
  auth_nickname:{
    type:String,
    trim:true,
  },
  auth_profile_image:{
    type:String,
    trim:true,
  },
  auth_thumbnail_image:{
    type:String,
    trim:true,
  },
  createdAt:{
    type:Date,
    default:Date.now
  },
  email:{
    type:String,
    match:[/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,"Should be a vaild email address!"],
    trim:true,
  },
},{
  toObject:{virtuals:true}
});

var User = mongoose.model("user",userSchema);
module.exports = User;
