var mongoose = require("mongoose");

var roomSchema = mongoose.Schema({
  roomname:{
    type:String,
    required:[true,"roomname is required!"],
    trim:true,
  },
  createdAt:{
    type:Date,
    default:Date.now
  },
  updatedAt:{
    type:Date,
    default:Date.now
  },
  master:{
    type:mongoose.Schema.Types.ObjectId,
    ref:'user',
    required:true,
  },
  users:[
    {
      type:mongoose.Schema.Types.ObjectId,
      ref:'user',
      required:true,
    }
  ],
},{
  toObject:{virtuals:true}
});

var Room = mongoose.model("room",roomSchema);
module.exports = Room;
