// define constructor function that gets `io` send to it
module.exports = function(io) {
  const chatio = io.of('/chat');
  chatio.on('connection', function(socket){

    socket.on('join room',function(room_id, username){
      socket.username = username;
      socket.room_id = room_id;
      socket.join(room_id);

      console.log(socket.room_id, socket.id, socket.username, 'connect');

      chatio.to(socket.room_id).emit('join room', {
        username: socket.username
      });

    });
  });
}
