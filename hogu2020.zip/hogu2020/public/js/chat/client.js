const socket = io('/chat');

// join room
socket.emit('join room',room_id,username);

$('form').submit(function(){
	if($('#chatInput').val()[0]==='/'){
			if($('#chatInput').val()[1]==='s'){
				socket.emit('game start');
				$('#chatInput').val('');
			}
			else if($('#chatInput').val()[1]==='e'){
				socket.emit('game end');
				$('#chatInput').val('');
			}
			else if($('#chatInput').val()[1]==='c'){
				socket.emit('game continue');
				$('#chatInput').val('');
			}
	}
	else if($('#chatInput').val()===''){
		return false;
	}
	else{
  	socket.emit('chat message', $('#chatInput').val());
  	$('#chatInput').val('');
	}
	return false;
}); //client에서 server로 msg 전송

socket.on('game next', function() {
	socket.emit('game continue');
});

socket.on('join room', function(data) {
	var span = $('<span class="nickname">').text(data.username).append(' ');
	var li = $('<li>').append(span).append('joined').css('color', getColor(data.username));
	$('#message').append(li);
	$("#message").animate({scrollTop: $('#message').prop("scrollHeight")}, 0);
}); //user join

socket.on('leave room', function(data) {
	var span = $('<span class="nickname">').text(data.username).append(' ');
	var li = $('<li>').append(span).append('leaved').css('color', getColor(data.username));
	$('#message').append(li);
	$("#message").animate({scrollTop: $('#message').prop("scrollHeight")}, 0);
});

socket.on('chat message', function(data){
	var span = $('<span class="nickname">').text(data.username).append(' : ');
	var li = $('<li>').append(span).append(data.message).css('color', getColor(data.username));
	$('#chatMsg').append(li);
	$("#chatMsg").animate({scrollTop: $('#chatMsg').prop("scrollHeight")}, 0);
}); //chat 내용을 채팅창에 출력

socket.on('chat message bluff', function(data){
	var span = $('<span class="nickname">').text(data.username).append(' : ');
	var li = $('<li>').append(span).append('bluff!!!').css('color', getColor(data.username));
	$('#message').append(li);
	$("#message").animate({scrollTop: $('#message').prop("scrollHeight")}, 0);
}); //chat 내용을 채팅창에 출력

socket.on('game message', function(data){
	soundBluff();

	var span = $('<span class="nickname">').text('[Game Manager]').append(' ');
	var li = $('<li>').append(span).css('color', '#79CF9F').append(data.message);
	$('#message').append(li);
	$("#message").animate({scrollTop: $('#message').prop("scrollHeight")}, 0);
}); //chat 내용을 채팅창에 출력

socket.on('game dice', function(gmInfo){
	var curDice = gmInfo.curDice;
	var curDiceN = gmInfo.curDiceN;

	document.getElementById("gameDice").innerHTML = curDice;
	document.getElementById("gameDiceN").innerHTML = curDiceN;
	document.getElementById("userDice").value = curDice;
	document.getElementById("userDiceN").value = curDiceN;
}); //current game dice

socket.on('game dice total', function(diceTotal){
	document.getElementById("diceTotal").innerHTML = 'x'.concat(diceTotal);
}); //current game dice

socket.on('create table', function(data){
	deleteTable();
	createTable(data.turnInfo, data.playersInfo);
});

socket.on('change turn table', function(player){
	changeTurnTable(player);
	soundDiceRoll();
})

socket.on('disable turn', function(data){
	disableBtnRoll();
});

socket.on('enable turn', function(data){
	enableBtnRoll();
});

function emitRoll() {
	var userDice = document.getElementById("userDice").value;
	var userDiceN = document.getElementById("userDiceN").value;
	socket.emit('user roll',{
		dice: userDice,
		diceN: userDiceN
	});
}

function emitBluff() {
	socket.emit('user bluff');
}

var COLORS = [
	'#e21400', '#91580f', '#f8a700', '#f78b00',
	'#58dc00', '#287b00', '#a8f07a', '#4ae8c4',
	'#3b88eb', '#3824aa', '#a700ff', '#d300e7'
];
var USERCOLORS = {
	elca: '#8b00ff',
	강날두: '#d45cda',
	푸어맨: '#E8B760',
	자오기: '#0000FF',
	가라마: '#FF0000',
}

function getColor(username){
	if (USERCOLORS[username] !== undefined) {
		return USERCOLORS[username];
	}
	var hash = 7;
	for (var i = 0; i < username.length; i++) {
		 hash = username.charCodeAt(i) + (hash << 5) - hash;
	}
	var index = Math.abs(hash % COLORS.length);
	return COLORS[index];
}// 이름에 색칠 정해주기
