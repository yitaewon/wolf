var express = require("express");
var router  = express.Router();
var util     = require("../util");
var Score    = require('../models/Score');

router.get("/", function(req, res){
  res.redirect('score/hidden');
});

// Hidden
router.get('/hidden',  function(req, res){
  Score.find({})
  .sort('-index')
  .exec(function(err, scores){
    if(err) return res.json(err);
    res.render('score/hidden', {scores:scores});
  });
});

// Result
router.get('/result',  function(req, res){
  Score.find({})
  .sort('-index')
  .exec(function(err, scores){
    if(err) return res.json(err);
    res.render('score/result', {scores:scores});
  });
});

// New
router.get('/new', function(req, res){
  res.render('score/new');
});

// create
router.post('/', function(req, res){
  Score.create(req.body, function(err, score){
    if(err) return res.json(err);
    res.redirect('/score');
  });
});

// edit
router.get('/:id/edit',function(req, res){
  Score.findOne({_id:req.params.id}, function(err, score){
    if(err) return res.json(err);
    res.render('score/edit', {score:score});
  });
});

// update
router.put('/:id', function(req, res){
  Score.findOneAndUpdate({_id:req.params.id}, req.body, function(err, score){
    if(err) return res.json(err);
    res.redirect('/score');
  });
});

// destroy
router.delete('/:id', function(req, res){
  Score.deleteOne({_id:req.params.id}, function(err){
    if(err) return res.json(err);
    res.redirect('/score');
  });
});

module.exports = router;
