var express = require("express");
var router  = express.Router();
var passport= require("../config/passport");

// Home
router.get("/", function(req, res){
  res.render("home/index");
});
router.get("/home", function(req, res){
  res.render("home/index");
});

// Login
router.get("/login", function (req,res) {
  var username = req.flash("username")[0];
  var errors = req.flash("errors")[0] || {};
  res.render("home/login", {
    username:username,
    errors:errors
  });
});

// Logout
router.get("/logout", function(req, res) {
  req.logout();
  res.redirect("/home");
});

// kakao 로그인
router.get('/auth/login/kakao',
  passport.authenticate('kakao')
);

// kakao 로그인 연동 콜백
router.get('/auth/login/kakao/callback',
  passport.authenticate('kakao', {
    successRedirect: '/home',
    failureRedirect: '/home'
  })
);

module.exports = router;
