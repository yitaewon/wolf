var express = require("express");
var router  = express.Router();
var util    = require("../util");
var Room    = require('../models/Room');

router.get("/", util.isLoggedin, function(req, res){
  Room.find({})
  .sort('-updatedAt')
  .exec(function(err, rooms){
    if(err) return res.json(err);
    res.render('blackjack/index', {rooms:rooms});
  });
});

// New
router.get('/new', util.isLoggedin, function(req, res){
  res.render('blackjack/new');
});

// create
router.post('/', util.isLoggedin, function(req, res){
  req.body.master = req.user._id;
  Room.create(req.body, function(err, room){
    if(err) return res.json(err);
    res.redirect('/blackjack/'+room._id);
  });
});

// show
router.get('/:id', util.isLoggedin, function(req, res){
  Room.findOne({_id:req.params.id}, function(err, room){
    if(err) return res.json(err);
    if(room.users.indexOf(req.user._id) === -1){
      room.users.push(req.user._id);
      room.save();
    }
  });

  Room.findOne({_id:req.params.id})
    .populate('users')
    .populate('master')
    .exec(function(err, room){
      if(err) return res.json(err);
      res.render('blackjack/show', {room:room,username:req.user.username});
  });

});

// edit
router.get('/:id/edit', util.isLoggedin, checkPermission, function(req, res){
  Room.findOne({_id:req.params.id}, function(err, room){
    if(err) return res.json(err);
    res.render('blackjack/edit', {room:room});
  });
});

// update
router.put('/:id', util.isLoggedin, checkPermission, function(req, res){
  req.body.updatedAt = Date.now();
  Room.findOneAndUpdate({_id:req.params.id}, req.body, function(err, room){
    if(err) return res.json(err);
    res.redirect("/blackjack/"+req.params.id);
  });
});

// destroy
router.delete('/:id', util.isLoggedin, checkPermission, function(req, res){
  Room.deleteOne({_id:req.params.id}, function(err){
    if(err) return res.json(err);
    res.redirect('/blackjack');
  });
});

module.exports = router;

// private functions
function checkPermission(req, res, next){
  Room.findOne({_id:req.params.id}, function(err, room){
    if(err) return res.json(err);
    if(room.master != req.user.id) return util.noPermission(req, res);

    next();
  });
}
