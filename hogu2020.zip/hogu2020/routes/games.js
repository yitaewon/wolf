var express = require("express");
var router  = express.Router();
var util     = require("../util");
var Room = require('../models/Room');

router.get("/", function(req, res){
  res.render("games/index");
});

module.exports = router;
